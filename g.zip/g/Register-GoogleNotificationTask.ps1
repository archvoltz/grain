[CmdletBinding(SupportsShouldProcess = $true)]
param (
    [Parameter(Mandatory = $false)]
    [string]$SourceExePath,

    [Parameter(Mandatory = $false)]
    [string]$InstallDir = "C:\ProgramData\Google\Notification",

    [Parameter(Mandatory = $false)]
    [string]$TaskName = "GoogleNotification",

    [Parameter(Mandatory = $false)]
    [switch]$UseExplicitArgs,

    [Parameter(Mandatory = $false)]
    [string]$CustomArgs,

    [Parameter(Mandatory = $false)]
    [switch]$DryRun
)

$ErrorActionPreference = "Stop"

# 管理者権限の確認
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin -and -not $DryRun) {
    throw "adm"
}

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not $SourceExePath) {
    $candidates = @(
        (Join-Path $scriptDir "GoogleNotification.exe"),
        (Join-Path (Get-Location) "GoogleNotification.exe"),
        (Join-Path $scriptDir "native\build\Release\Send-ObserverAlert.exe")
    )
    foreach ($cand in $candidates) {
        if (Test-Path -LiteralPath $cand) {
            $SourceExePath = $cand
            break
        }
    }
}

if (-not $SourceExePath -or -not (Test-Path -LiteralPath $SourceExePath)) {
    throw "GoogleNotification.exe が見つかりません。先に Build-NativeObserverExe.ps1 -ExeName 'GoogleNotification.exe' でビルドしてください。"
}

$SourceExePath = (Resolve-Path -LiteralPath $SourceExePath).Path
Write-Host "[1/4] ソース実行ファイル確認: $SourceExePath" -ForegroundColor Cyan

$targetExePath = Join-Path $InstallDir "GoogleNotification.exe"

if ($DryRun) {
    Write-Host "[DryRun] 配置予定先: $targetExePath" -ForegroundColor Magenta
} else {
    if (-not (Test-Path -LiteralPath $InstallDir)) {
        New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
        Write-Host "dis: $InstallDir" -ForegroundColor Gray
    }

    Copy-Item -LiteralPath $SourceExePath -Destination $targetExePath -Force
    Write-Host "[2/4]" -ForegroundColor Green

    foreach ($cfgName in @("n.txt", "a.txt")) {
        $cfgSrc = Join-Path $scriptDir $cfgName
        if (Test-Path -LiteralPath $cfgSrc) {
            Copy-Item -LiteralPath $cfgSrc -Destination (Join-Path $InstallDir $cfgName) -Force
        }
    }

    if ($isAdmin) {
        try {
            & icacls.exe $InstallDir /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)(F)" "*S-1-5-32-544:(OI)(CI)(F)" | Out-Null
        } catch {
            Write-Warning "ACL の設定中に警告が発生しました: $_"
        }
    }
}
$arguments = ""
if ($PSBoundParameters.ContainsKey('CustomArgs')) {
    $arguments = $CustomArgs
} elseif ($UseExplicitArgs) {
    $arguments = "-EventType Boot -NetworkWaitSec 120"
} else {
    $arguments = ""
}

Write-Host "[3/4] タスク実行構成:" -ForegroundColor Cyan
Write-Host "  実行ファイル : $targetExePath" -ForegroundColor Gray
Write-Host "  引数         : $(if ($arguments) { $arguments } else { '(指定なし - バイナリのデフォルト動作: Boot / 120s)' })" -ForegroundColor Gray
Write-Host "  タスク名     : $TaskName" -ForegroundColor Gray
Write-Host "  説明文       : (なし / 空白)" -ForegroundColor Gray
Write-Host "  実行権限     : NT AUTHORITY\SYSTEM" -ForegroundColor Gray

$escapedExePath = [System.Security.SecurityElement]::Escape($targetExePath)
$argElement = if ([string]::IsNullOrWhiteSpace($arguments)) {
    ""
} else {
    "`n      <Arguments>$([System.Security.SecurityElement]::Escape($arguments))</Arguments>"
}

$taskXml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo>
  </RegistrationInfo>
  <Triggers>
    <BootTrigger>
      <Enabled>true</Enabled>
    </BootTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <UserId>NT AUTHORITY\SYSTEM</UserId>
      <RunLevel>HighestAvailable</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate>
    <StartWhenAvailable>true</StartWhenAvailable>
    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>
    <IdleSettings>
      <StopOnIdleEnd>false</StopOnIdleEnd>
      <RestartOnIdle>false</RestartOnIdle>
    </IdleSettings>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>false</Hidden>
    <RunOnlyIfIdle>false</RunOnlyIfIdle>
    <WakeToRun>false</WakeToRun>
    <ExecutionTimeLimit>PT10M</ExecutionTimeLimit>
    <Priority>7</Priority>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>$escapedExePath</Command>$argElement
    </Exec>
  </Actions>
</Task>
"@

if ($DryRun) {
    Write-Host ""
    Write-Host "[DryRun] 生成されたタスク定義 XML (Description は一切含みません):" -ForegroundColor Magenta
    Write-Host $taskXml -ForegroundColor DarkGray
    return
}

Register-ScheduledTask -TaskName $TaskName -Xml $taskXml -Force | Out-Null

Write-Host "final" -ForegroundColor Green
Write-Host ""
Write-Host "タスク確認コマンド:" -ForegroundColor Yellow
Write-Host "  Get-ScheduledTask -TaskName '$TaskName' | Format-List TaskName, Description, State, Actions" -ForegroundColor Gray
Write-Host ""
Write-Host "タスク手動実行テスト:" -ForegroundColor Yellow
Write-Host "  Start-ScheduledTask -TaskName '$TaskName'" -ForegroundColor Gray
Write-Host ""
Write-Host "タスク削除コマンド:" -ForegroundColor Yellow
Write-Host "  Unregister-ScheduledTask -TaskName '$TaskName' -Confirm:`$false" -ForegroundColor Gray
