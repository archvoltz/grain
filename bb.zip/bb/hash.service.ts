import { Injectable, Logger } from '@nestjs/common';
import * as bcrypt from 'bcryptjs';

@Injectable()
export class HashService {
  constructor(private readonly logger: Logger) {}
  makeHash = async (_traget: string, _salt: string) => {
    try {
      const hashedPassword = await bcrypt.hash(_traget, _salt);
      return hashedPassword;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(`makeHash failed: ${err.message}`, err, 'HashService');
      return e;
    }
  };

  checkPassword = async (_target: string, _userInput: string) => {
    try {
      const result = await bcrypt.compare(_userInput, _target);
      return result;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `checkPassword failed: ${err.message}`,
        err,
        'HashService',
      );
      return false;
    }
  };
}
