import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from 'src/prisma.service';
import { UserOnProject, Prisma } from '../generated/prisma/client';

@Injectable()
export class UserOnProjectService {
  constructor(
    private prisma: PrismaService,
    private readonly logger: Logger,
  ) {}

  async createUserOnProject(data: {
    roleId: number;
    userId: string;
    projectId: string;
  }): Promise<UserOnProject> {
    try {
      const result = await this.prisma.userOnProject.create({
        data,
      });

      this.logger.log(
        `member added: user=${result?.userId} project=${result?.projectId} role=${result?.roleId}`,
        'UserOnProjectService',
      );
      return result;
    } catch (error) {
      const err = error instanceof Error ? error : new Error(String(error));
      this.logger.error(
        `createUserOnProject failed: ${err.message}`,
        err,
        'UserOnProjectService',
      );
      throw error;
    }
  }

  async getUserOnProject(params: {
    skip?: number;
    take?: number;
    include?: Prisma.UserOnProjectInclude;
    cursor?: Prisma.UserOnProjectWhereUniqueInput;
    where?: Prisma.UserOnProjectWhereInput;
    orderBy?: Prisma.UserOnProjectOrderByWithAggregationInput;
  }): Promise<UserOnProject[]> {
    const { skip, take, cursor, where, orderBy, include } = params;
    try {
      const result = await this.prisma.userOnProject.findMany({
        skip,
        take,
        include,
        cursor,
        where,
        orderBy,
      });
      this.logger.debug(
        `userOnProject fetched: ${result.length}`,
        'UserOnProjectService',
      );
      return result;
    } catch (error) {
      const err = error instanceof Error ? error : new Error(String(error));
      this.logger.error(
        `getUserOnProject failed: ${err.message}`,
        err,
        'UserOnProjectService',
      );
      throw error;
    }
  }

  async updateUserOnProject(prams: {
    where: Prisma.UserOnProjectWhereUniqueInput;
    data: Prisma.UserOnProjectUpdateInput;
  }): Promise<UserOnProject> {
    const { where, data } = prams;
    try {
      const result = await this.prisma.userOnProject.update({
        where,
        data,
      });

      this.logger.log(
        `member updated: user=${result?.userId} project=${result?.projectId} role=${result?.roleId}`,
        'UserOnProjectService',
      );
      return result;
    } catch (error) {
      const err = error instanceof Error ? error : new Error(String(error));
      this.logger.error(
        `updateUserOnProject failed: ${err.message}`,
        err,
        'UserOnProjectService',
      );
      throw error;
    }
  }

  async deleteUserOnProject(
    where: Prisma.UserOnProjectWhereUniqueInput,
  ): Promise<UserOnProject> {
    try {
      const result = await this.prisma.userOnProject.delete({
        where,
      });
      this.logger.log(
        `member removed: user=${result?.userId} project=${result?.projectId}`,
        'UserOnProjectService',
      );
      return result;
    } catch (error) {
      const err = error instanceof Error ? error : new Error(String(error));
      this.logger.error(
        `deleteUserOnProject failed: ${err.message}`,
        err,
        'UserOnProjectService',
      );
      throw error;
    }
  }

  async moreThanOneAdmin(
    _projectId: string,
    _userId: string,
  ): Promise<boolean> {
    const users = await this.prisma.userOnProject.findMany({
      where: {
        projectId: _projectId,
      },
    });
    const adminsWithoutTarget = users.filter(
      (target) => target.roleId == 0 && target.userId != _userId,
    );

    this.logger.debug(
      `other admins on project=${_projectId} except user=${_userId}: ${adminsWithoutTarget.length}`,
      'UserOnProjectService',
    );
    if (adminsWithoutTarget.length != 0) return true;
    return false;
  }
}
