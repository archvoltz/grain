import { Injectable, Logger } from '@nestjs/common';
import { SmartContract, Prisma } from '../generated/prisma/client';
import { PrismaService } from 'src/prisma.service';

@Injectable()
export class SmartContractService {
  constructor(
    private prisma: PrismaService,
    private readonly logger: Logger,
  ) {}

  async createContract(
    _newSmartContract: Prisma.SmartContractCreateInput,
  ): Promise<string | SmartContract> {
    try {
      const res = await this.prisma.smartContract.create({
        data: _newSmartContract,
      });
      this.logger.log(
        `contract created: ${res?.contractId}`,
        'SmartContractService',
      );
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `createContract failed: ${err.message}`,
        err,
        'SmartContractService',
      );
      throw e;
    }
  }

  async getContracts(params: {
    skip?: number;
    take?: number;
    cursor?: Prisma.SmartContractWhereUniqueInput;
    where?: Prisma.SmartContractWhereInput;
    orderBy?: Prisma.SmartContractOrderByWithRelationInput;
    include?: Prisma.SmartContractInclude;
  }): Promise<SmartContract[]> {
    const { skip, take, cursor, where, orderBy, include } = params;
    try {
      const res = await this.prisma.smartContract.findMany({
        skip,
        take,
        cursor,
        where,
        orderBy,
        include,
      });
      this.logger.debug(
        `contracts fetched: ${res.length}`,
        'SmartContractService',
      );
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `getContracts failed: ${err.message}`,
        err,
        'SmartContractService',
      );
      throw e;
    }
  }

  async getContractById(
    _targetId: Prisma.SmartContractWhereUniqueInput,
  ): Promise<SmartContract> {
    try {
      const res = await this.prisma.smartContract.findUnique({
        where: _targetId,
        include: {
          tag: true,
        },
      });
      if (!res) {
        this.logger.warn(
          `contract not found: ${String(_targetId?.contractId)}`,
          'SmartContractService',
        );
      }
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `getContractById failed: ${err.message}`,
        err,
        'SmartContractService',
      );
      throw e;
    }
  }

  async updateContract(params: {
    where: Prisma.SmartContractWhereUniqueInput;
    data: Prisma.SmartContractUpdateInput;
  }): Promise<SmartContract> {
    const { where, data } = params;
    try {
      const res = await this.prisma.smartContract.update({
        where,
        data,
      });
      this.logger.debug(
        `contract updated: ${res?.contractId}`,
        'SmartContractService',
      );
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `updateContract failed: ${err.message}`,
        err,
        'SmartContractService',
      );
      throw e;
    }
  }

  async deleteContract(
    where: Prisma.SmartContractWhereUniqueInput,
  ): Promise<SmartContract> {
    try {
      const res = await this.prisma.smartContract.delete({
        where,
      });
      this.logger.log(
        `contract deleted: ${res?.contractId}`,
        'SmartContractService',
      );
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `deleteContract failed: ${err.message}`,
        err,
        'SmartContractService',
      );
      throw e;
    }
  }
}
