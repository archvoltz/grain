import type { AppErrorCode } from '../interfaces/error-response.interface';

export type LogEvent =
  | 'http_request'
  | 'login_succeeded'
  | 'login_failed'
  | 'logout'
  | 'app_started';

export interface LogFields {
  clientIp: string;
  timestamp: string;
  severity: 'INFO' | 'WARN' | 'ERROR' | 'DEBUG';
  service: string;
  version: string;
  event: LogEvent | '';
  requestId: string;
  userId: string;
  message: string;
  UserAgent: string;
}

export interface HttpFields {
  method: string;
  path: string;
  status: number;
  durationMs: number;
}

export interface ErrorFields {
  code: AppErrorCode | '';
  type: string;
  detail: string;
  stack: string;
}

export interface RequestErrorContext {
  message: string;
  error: ErrorFields;
}

export function appErrorCodeFromStatus(status: number): AppErrorCode {
  switch (status) {
    case 400:
      return 'BAD_REQUEST';
    case 401:
      return 'UNAUTHORIZED';
    case 403:
      return 'FORBIDDEN';
    case 404:
      return 'NOT_FOUND';
    case 409:
      return 'CONFLICT';
    case 422:
      return 'VALIDATION_ERROR';
    case 429:
      return 'RATE_LIMITED';
    default:
      return status >= 500 ? 'INTERNAL_ERROR' : 'UNKNOWN_ERROR';
  }
}

export function severityFromStatus(status: number): LogFields['severity'] {
  if (status >= 500) return 'ERROR';
  if (status >= 400) return 'WARN';
  return 'INFO';
}

const serviceName = () => process.env.LOG_SERVICE || 'f8-api';
const appVersion = () => process.env.APP_VERSION || '0.0.0';

export const STACK_MAX_BYTES = 4096;

const s = (v: unknown): string =>
  v === undefined || v === null ? '' : String(v);

export function truncateStack(stack: unknown): string {
  const text = s(stack);
  if (Buffer.byteLength(text, 'utf8') <= STACK_MAX_BYTES) return text;
  const cut = Buffer.from(text, 'utf8')
    .subarray(0, STACK_MAX_BYTES)
    .toString('utf8');
  return `${cut}\n...[truncated at ${STACK_MAX_BYTES} bytes]`;
}

export function buildLogFields(partial: Partial<LogFields> = {}): LogFields {
  return {
    clientIp: s(partial.clientIp),
    timestamp: partial.timestamp || new Date().toISOString(),
    severity: partial.severity || 'INFO',
    service: partial.service || serviceName(),
    version: partial.version || appVersion(),
    event: partial.event || '',
    requestId: s(partial.requestId),
    userId: s(partial.userId),
    message: s(partial.message),
    UserAgent: s(partial.UserAgent),
  };
}

export function buildLogRecord(
  partial: Partial<LogFields> = {},
  extra: Partial<HttpFields> = {},
  error?: Partial<ErrorFields>,
): Record<string, unknown> {
  const merged: Record<string, unknown> = { ...buildLogFields(partial) };

  if (extra.method !== undefined) merged.method = s(extra.method);
  if (extra.path !== undefined) merged.path = s(extra.path);
  if (extra.status !== undefined) merged.status = extra.status;
  if (extra.durationMs !== undefined) merged.durationMs = extra.durationMs;

  if (error) {
    merged.error = {
      code: s(error.code),
      type: s(error.type),
      detail: s(error.detail),
      stack: truncateStack(error.stack),
    };
  }
  return merged;
}

export function formatLogLine(
  partial: Partial<LogFields> = {},
  extra: Partial<HttpFields> = {},
  error?: Partial<ErrorFields>,
): string {
  return JSON.stringify(buildLogRecord(partial, extra, error));
}
