import { Logger, Module } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import { HashService } from './hash.service';
import { ConfigService } from '@nestjs/config';
import { APIKeyService } from './apiKey/apiKey.service';
import { RedisService } from './redis/redis.service';
import { RequestContextService } from './requestContext.service';

@Module({
  providers: [
    PrismaService,
    HashService,
    ConfigService,
    APIKeyService,
    RedisService,
    Logger,
    RequestContextService,
  ],
  exports: [
    PrismaService,
    HashService,
    ConfigService,
    APIKeyService,
    RedisService,
    Logger,
    RequestContextService,
  ],
})
export class SharedModule {}
