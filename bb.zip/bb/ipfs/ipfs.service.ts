import { Injectable, Logger } from '@nestjs/common';
import { PinataSDK } from 'pinata-web3';
import {
  IpfsUrlDTO,
  MetadataDto,
  MetadataResultDto,
  UploadIpfsDTO,
  UrlAndMetadataUploadDto,
} from 'src/dto/ipfs.dto';

@Injectable()
export class IpfsService {
  constructor(private readonly logger: Logger) {}

  pinata = new PinataSDK({
    pinataJwt: process.env.PINATA_API_JWT,
    pinataGateway: process.env.PINATA_GATEWAY || 'gateway.pinata.cloud',
  });

  async uploadMetadata(_data: MetadataDto): Promise<MetadataResultDto> {
    const startedAt = Date.now();
    try {
      if (typeof _data.attributes === 'string') {
        _data.attributes = JSON.parse(_data.attributes);
      }

      const image_hash = await this.pinata.upload
        .json(_data)
        .addMetadata({ name: 'test.json' });
      await this.pinata.updateMetadata({
        cid: image_hash.IpfsHash,
        name: `${image_hash.IpfsHash}.json`,
      });
      const result = (await this.pinata.gateways.get(image_hash.IpfsHash))
        .data as MetadataDto;
      this.logger.debug(
        `metadata uploaded: cid=${image_hash.IpfsHash} ${Date.now() - startedAt}ms`,
        'IpfsService',
      );
      return { metaData: result, ipfsHash: image_hash.IpfsHash };
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `uploadMetadata failed after ${Date.now() - startedAt}ms: ${err.message}`,
        err,
        'IpfsService',
      );
      return e;
    }
  }

  async uploadURL(_data: IpfsUrlDTO): Promise<UploadIpfsDTO> {
    const startedAt = Date.now();
    try {
      const result = await this.pinata.upload.url(_data.imageFileUrl);
      await this.pinata.updateMetadata({
        cid: result.IpfsHash,
        name: `${result.IpfsHash}.jpg`,
      });
      this.logger.debug(
        `url uploaded: cid=${result.IpfsHash} ${Date.now() - startedAt}ms`,
        'IpfsService',
      );
      return result;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `uploadURL failed after ${Date.now() - startedAt}ms: url=${_data.imageFileUrl} ${err.message}`,
        err,
        'IpfsService',
      );
      return e;
    }
  }

  async uploadUrlAndMetadata(
    _data: UrlAndMetadataUploadDto,
  ): Promise<MetadataResultDto> {
    const { imageFileUrl, ...metaData } = _data;
    const target = await this.uploadURL({ imageFileUrl: imageFileUrl });

    if (!target.IpfsHash) {
      this.logger.warn(
        `uploadUrlAndMetadata aborted: no IpfsHash for url=${imageFileUrl}`,
        'IpfsService',
      );
      throw new Error('Upload Faild');
    }
    const result = await this.uploadMetadata(metaData);
    return result;
  }

  async uploadBlob(_blob: Blob): Promise<UploadIpfsDTO> {
    const startedAt = Date.now();
    const extention = await this.getExtentionName(_blob);

    if (!extention) {
      this.logger.warn(
        `unsupported blob type: ${_blob.type || '(empty)'}`,
        'IpfsService',
      );
    }
    const file = new File([_blob], `fromAPI.${extention}`, {
      type: _blob.type,
    });
    const result = await this.pinata.upload.file(file);
    this.logger.debug(
      `blob uploaded: cid=${result?.IpfsHash} size=${_blob.size} ${Date.now() - startedAt}ms`,
      'IpfsService',
    );
    return result;
  }

  async uploadDataURI(_data: string): Promise<UploadIpfsDTO> {
    const dataURIParts = _data.split(',');
    const mimeType = dataURIParts[0].split(':')[1].split(';')[0];
    const base64Data = dataURIParts[1];

    const byteCharacters = atob(base64Data);
    const byteArrays = new Uint8Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteArrays[i] = byteCharacters.charCodeAt(i);
    }
    if (mimeType === 'image/svg+xml' || mimeType === 'text/html') {
      try {
        const content = new TextDecoder().decode(byteArrays);
        let decodedContent: string;
        try {
          decodedContent = decodeURIComponent(content);
        } catch {
          decodedContent = content;
        }
        const blob = new Blob([decodedContent], { type: mimeType });
        return this.uploadBlob(blob);
      } catch (error) {
        const err = error instanceof Error ? error : new Error(String(error));
        this.logger.error(
          `uploadDataURI failed: mime=${mimeType} ${err.message}`,
          err,
          'IpfsService',
        );
        throw new Error(error);
      }
    } else {
      const blob = new Blob([byteArrays], { type: mimeType });
      return this.uploadBlob(blob);
    }
  }

  async getExtentionName(_blob: Blob): Promise<string> {
    switch (_blob.type) {
      case 'image/png':
        return 'png';
      case 'image/jpeg':
        return 'jpg';
      default:
        return undefined;
    }
  }
}
