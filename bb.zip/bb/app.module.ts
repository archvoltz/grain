import { Module, MiddlewareConsumer } from '@nestjs/common';
import { APP_FILTER } from '@nestjs/core';
import { ConfigModule } from '@nestjs/config';
import { AuthModule } from './auth/auth.module';
import { AuthMiddleware } from './middleware/auth.middleware';
import { SmartContractModule } from './SmartContract/SmartContract.module';
import { Web3Module } from './web3/web3.module';
import { UserProjectModule } from './user/userProject.module';
import { RoleModule } from './role/role.module';
import { TagModule } from './tag/tag.module';
import { IpfsModule } from './ipfs/ipfs.module';
import { CustomModule } from './custom/custom.module';
import { AllExceptionsFilter } from './filters';
import { HttpLoggerMiddleware } from './middleware/http-logger.middleware';
import { SharedModule } from './shared.module';

@Module({
  imports: [
    ConfigModule.forRoot(),
    AuthModule,
    SmartContractModule,
    Web3Module,
    UserProjectModule,
    IpfsModule,
    RoleModule,
    TagModule,
    CustomModule,
    SharedModule,
  ],
  providers: [{ provide: APP_FILTER, useClass: AllExceptionsFilter }],
})
export class AppModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(HttpLoggerMiddleware).forRoutes('*');
    consumer.apply(AuthMiddleware).forRoutes('AppController');
  }
}
