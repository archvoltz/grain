import { Injectable, NestMiddleware, Logger } from '@nestjs/common';
import { NextFunction, Request, Response } from 'express';
import { RequestContextService } from '../requestContext.service';
import type { RequestErrorContext } from '../logger/log-line';

export const REQUEST_ID_HEADER = 'x-request-id';

export interface RequestWithErrorInfo extends Request {
  errorInfo?: RequestErrorContext;
}

function clientIpOf(req: Request): string {
  const xff = req.headers['x-forwarded-for'];
  const first = Array.isArray(xff) ? xff[0] : xff;
  if (first) return first.split(',')[0].trim();
  return req.socket?.remoteAddress ?? '';
}

@Injectable()
export class HttpLoggerMiddleware implements NestMiddleware {
  constructor(
    private readonly logger: Logger,
    private readonly requestContext: RequestContextService,
  ) {}

  use(req: RequestWithErrorInfo, res: Response, next: NextFunction) {
    const header = req.headers[REQUEST_ID_HEADER];
    const context = this.requestContext.create({
      clientIp: clientIpOf(req),
      UserAgent: req.headers['user-agent'],
      requestId: Array.isArray(header) ? header[0] : header,
    });
    res.setHeader(REQUEST_ID_HEADER, context.requestId);

    const startedAt = Date.now();
    res.on('finish', () => {
      const errorInfo = req.errorInfo;

      this.requestContext.run(context, () =>
        this.logger.log(
          {
            method: req.method,
            path: req.originalUrl,
            status: res.statusCode,
            durationMs: Date.now() - startedAt,
          },
          {
            isMiddleware: true,
            message: errorInfo?.message,
            error: errorInfo?.error,
          },
        ),
      );
    });

    this.requestContext.run(context, () => next());
  }
}
