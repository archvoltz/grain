import { Injectable, UnauthorizedException, Logger } from '@nestjs/common';
import { Prisma } from '../generated/prisma/client';
import { APIKeyService } from 'src/apiKey/apiKey.service';
import { HashService } from 'src/hash.service';
import { ProjectService } from 'src/project/project.service';
import { UserService } from 'src/user/user.service';

@Injectable()
export class AuthService {
  constructor(
    private hashService: HashService,
    private apikeyService: APIKeyService,
    private projectService: ProjectService,
    private userService: UserService,
    private readonly logger: Logger,
  ) {}

  async validateApiKey(_key: string): Promise<boolean> {
    try {
      const apikey = await this.apikeyService.getApiKey({
        where: {
          key: _key,
        },
      });
      if (apikey instanceof Error) throw new UnauthorizedException();
      const result = await this.projectService.getProjectById({
        where: {
          projectId: apikey.projectId,
        },
      });
      if (result.length != 0) {
        return true;
      } else {
        this.logger.warn(
          `api key has no project: project=${apikey?.projectId}`,
          'AuthService',
        );
        return false;
      }
    } catch (e) {
      if (e instanceof UnauthorizedException) {
        this.logger.warn('api key validation failed', 'AuthService');
      } else {
        const err = e instanceof Error ? e : new Error(String(e));
        this.logger.error(
          `validateApiKey failed: ${err.message}`,
          err,
          'AuthService',
        );
      }
      return false;
    }
  }

  async validateHashedApikey(_key: string, _secretKey: string) {
    const apikey = await this.apikeyService
      .getApiKey({
        where: {
          key: _key,
        },
      })
      .catch(() => null);
    if (!apikey || apikey instanceof Error) throw new UnauthorizedException();
    const valid = await this.hashService.checkPassword(
      apikey.secret,
      _secretKey,
    );

    if (!valid) {
      this.logger.warn('api secret mismatch', 'AuthService');
    }
    return valid;
  }

  async getPasswordByName(_name: Prisma.UserWhereUniqueInput): Promise<any> {
    const res = await this.userService.getUserByName(_name);
    return res;
  }
}
