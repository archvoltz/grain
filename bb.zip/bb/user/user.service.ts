import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from 'src/prisma.service';
import { Prisma } from '../generated/prisma/client';

@Injectable()
export class UserService {
  constructor(
    private prisma: PrismaService,
    private readonly logger: Logger,
  ) {}

  async createNewUser(params: {
    data: Prisma.UserCreateInput;
    select?: Prisma.UserSelect;
  }): Promise<any> {
    const { data, select } = params;
    try {
      const res = await this.prisma.user.create({
        data: data,
        select: select,
      });

      this.logger.debug(`user created: ${res?.userId}`, 'UserService');
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `createNewUser failed: ${err.message}`,
        err,
        'UserService',
      );
      return e;
    }
  }

  async getAllUsers(): Promise<any> {
    const res = await this.prisma.user.findMany({
      select: {
        userId: true,
        name: true,
        role: true,
      },
    });

    this.logger.debug(`users in total: ${res.length}`, 'UserService');
    return res;
  }

  async getusers(params: {
    skip?: number;
    take?: number;
    cursor?: Prisma.UserWhereUniqueInput;
    where?: Prisma.UserWhereUniqueInput;
    orderBy?: Prisma.UserOrderByWithRelationInput;
  }): Promise<any> {
    const { skip, take, cursor, where, orderBy } = params;
    try {
      const res = await this.prisma.user.findMany({
        skip,
        take,
        cursor,
        where,
        orderBy,
        select: {
          userId: true,
          name: true,
          role: true,
        },
      });

      this.logger.debug(`users fetched: ${res.length}`, 'UserService');
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(`getusers failed: ${err.message}`, err, 'UserService');
      return e;
    }
  }

  async getUserById(_userId: Prisma.UserWhereUniqueInput): Promise<any> {
    try {
      const res = await this.prisma.user.findUnique({
        where: _userId,
        select: {
          userId: true,
          name: true,
          role: true,
        },
      });
      return res;
    } catch (e) {
      return e;
    }
  }

  async getUserByName(_name: Prisma.UserWhereUniqueInput): Promise<any> {
    try {
      const res = await this.prisma.user.findUnique({
        where: _name,
        select: {
          userId: true,
          name: true,
          role: true,
          password: true,
        },
      });

      if (!res) {
        this.logger.warn(
          `user not found by name: ${String(_name?.name)}`,
          'UserService',
        );
      }
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `getUserByName failed: ${err.message}`,
        err,
        'UserService',
      );
      return e;
    }
  }

  async updateUser(params: {
    where: Prisma.UserWhereUniqueInput;
    data: Prisma.UserUpdateInput;
  }): Promise<any> {
    const { where, data } = params;
    try {
      const res = await this.prisma.user.update({
        where,
        data,
        select: {
          userId: true,
          name: true,
          role: true,
        },
      });
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `updateUser failed: ${err.message}`,
        err,
        'UserService',
      );
      return e;
    }
  }

  async deleteUser(where: Prisma.UserWhereUniqueInput): Promise<any> {
    try {
      const res = await this.prisma.user.delete({
        where,
        select: {
          userId: true,
          name: true,
          role: true,
        },
      });
      return res;
    } catch (e) {
      return e;
    }
  }
}
