import {
  Body,
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Param,
  HttpCode,
  HttpException,
  HttpStatus,
  UseGuards,
  Logger,
} from '@nestjs/common';
import { UserService } from './user.service';
import { Prisma, User } from '../generated/prisma/client';
import { HashService } from 'src/hash.service';
import { isStringObject } from 'util/types';
import {
  CreateUserBodyDto,
  DeleteUserBodyDto,
  UpdateUserBodyDto,
  UserResponseDto,
} from 'src/dto/user.dto';
import * as bcrypt from 'bcryptjs';
import {
  ApiCookieAuth,
  ApiResponse,
  ApiOperation,
  ApiBody,
  ApiExcludeController,
} from '@nestjs/swagger';
import { serviceAdminGuard } from 'src/guards/service-admin.guard';
import { userOwnGuard } from 'src/guards/user-own.guard';
import { DefaultFailedDto } from 'src/dto/auth.dto';
@Controller('user')
@ApiExcludeController()
export class UserController {
  constructor(
    private readonly userService: UserService,
    private hashService: HashService,
    private readonly logger: Logger,
  ) {}

  @Post()
  @HttpCode(201)
  @UseGuards(serviceAdminGuard)
  @ApiOperation({ summary: 'Create user at the service admin level.' })
  @ApiResponse({
    status: 201,
    description: 'created',
    type: UserResponseDto,
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
    type: DefaultFailedDto,
  })
  @ApiResponse({
    status: 409,
    description: 'Conflict',
    type: DefaultFailedDto,
  })
  @ApiResponse({
    status: 500,
    description: 'Server Error',
    type: DefaultFailedDto,
  })
  @ApiBody({
    description: 'User infomation for create new user',
    type: CreateUserBodyDto,
  })
  @ApiCookieAuth()
  async createUser(
    @Body()
    body: CreateUserBodyDto,
  ): Promise<UserResponseDto> {
    const { name, password, roleId } = body;
    const salt = await bcrypt.genSalt(10);

    const hashed = await this.hashService.makeHash(password, salt);
    if (hashed instanceof Error) {
      this.logger.error(
        `createUser: makeHash failed: ${hashed.message}`,
        hashed,
        'UserController',
      );
      throw new HttpException(
        {
          status: HttpStatus.INTERNAL_SERVER_ERROR,
          error: 'SERVER_ERROR',
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
    const hashedPassword = hashed;
    try {
      const result = await this.userService.createNewUser({
        data: {
          name: name,
          password: hashedPassword,
          role: {
            connect: {
              roleId: roleId,
            },
          },
        },
        select: {
          userId: true,
          name: true,
          role: true,
        },
      });

      if (result instanceof Error) throw result;
      return result;
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError) {
        throw new HttpException(
          {
            status: HttpStatus.CONFLICT,
            error: 'USERNAME_EMAIL_CONFLICT',
          },
          HttpStatus.CONFLICT,
        );
      } else if (e instanceof Prisma.PrismaClientValidationError) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'UNEXPECTED_INPUT',
          },
          HttpStatus.BAD_REQUEST,
        );
      } else {
        throw new HttpException(
          {
            status: HttpStatus.INTERNAL_SERVER_ERROR,
            error: 'SERVER_ERROR',
          },
          HttpStatus.INTERNAL_SERVER_ERROR,
        );
      }
    }
  }

  @Get()
  @HttpCode(200)
  @UseGuards(serviceAdminGuard)
  @ApiOperation({ summary: 'Get all users at the service admin level.' })
  @ApiResponse({ status: 200, description: 'ok', type: [UserResponseDto] })
  @ApiResponse({
    status: 500,
    description: 'Server Error',
    type: DefaultFailedDto,
  })
  @ApiCookieAuth()
  async getUsers(): Promise<UserResponseDto[]> {
    try {
      const result = await this.userService.getAllUsers();
      if (result instanceof Error) throw result;
      return result;
    } catch (e) {
      throw new HttpException(
        {
          status: HttpStatus.INTERNAL_SERVER_ERROR,
          error: 'SERVER_ERROR',
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Get(':id')
  @HttpCode(200)
  @UseGuards(userOwnGuard)
  @ApiOperation({
    summary: 'Get user detail at the user own level by user ID.',
  })
  @ApiResponse({ status: 200, description: 'ok', type: UserResponseDto })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
    type: DefaultFailedDto,
  })
  @ApiResponse({
    status: 500,
    description: 'Server Error',
    type: DefaultFailedDto,
  })
  @ApiCookieAuth()
  async getUserById(@Param('id') _id: string): Promise<UserResponseDto> {
    if (isStringObject(_id)) {
      throw new HttpException(
        {
          status: HttpStatus.BAD_REQUEST,
          error: 'APPLICATION_ERROR',
        },
        HttpStatus.BAD_REQUEST,
      );
    }
    try {
      const result = await this.userService.getUserById({
        userId: _id,
      });
      if (result instanceof Error) throw result;
      return result;
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'USER_NOT_FOUND',
          },
          HttpStatus.BAD_REQUEST,
        );
      } else if (e instanceof Prisma.PrismaClientValidationError) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'UNEXPECTED_INPUT',
          },
          HttpStatus.BAD_REQUEST,
        );
      } else {
        throw new HttpException(
          {
            status: HttpStatus.INTERNAL_SERVER_ERROR,
            error: 'SERVER_ERROR',
          },
          HttpStatus.INTERNAL_SERVER_ERROR,
        );
      }
    }
  }

  @Patch(':id')
  @HttpCode(200)
  @UseGuards(serviceAdminGuard)
  @ApiOperation({
    summary: 'Update user at the service admin level by user ID.',
  })
  @ApiBody({
    description: 'User information which admin can update',
    type: UpdateUserBodyDto,
  })
  @ApiResponse({ status: 200, description: 'OK', type: UserResponseDto })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
    type: DefaultFailedDto,
  })
  @ApiResponse({
    status: 409,
    description: 'Conflict',
    type: DefaultFailedDto,
  })
  @ApiResponse({
    status: 500,
    description: 'Server Error',
    type: DefaultFailedDto,
  })
  @ApiCookieAuth()
  async updateUser(
    @Param('id') _id: string,
    @Body()
    body: UpdateUserBodyDto,
  ): Promise<User> {
    const { name, roleId, password } = body;
    if (isStringObject(_id)) {
      throw new HttpException(
        {
          status: HttpStatus.BAD_REQUEST,
          error: 'APPLICATION_ERROR',
        },
        HttpStatus.BAD_REQUEST,
      );
    }
    const salt = await bcrypt.genSalt(10);
    let hashedPassword: string | undefined;
    if (password) {
      const hashed = await this.hashService.makeHash(password, salt);
      if (hashed instanceof Error) {
        this.logger.error(
          `updateUser: makeHash failed: ${hashed.message}`,
          hashed,
          'UserController',
        );
        throw new HttpException(
          {
            status: HttpStatus.INTERNAL_SERVER_ERROR,
            error: 'SERVER_ERROR',
          },
          HttpStatus.INTERNAL_SERVER_ERROR,
        );
      }
      hashedPassword = hashed;
    }

    try {
      const result = await this.userService.updateUser({
        where: { userId: _id },
        data: {
          name: name,
          password: hashedPassword,
          role: {
            connect: {
              roleId: roleId,
            },
          },
        },
      });
      if (result instanceof Error) throw result;
      return result;
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError) {
        throw new HttpException(
          {
            status: HttpStatus.CONFLICT,
            error: 'USERNAME_EMAIL_CONFLICT',
          },
          HttpStatus.CONFLICT,
        );
      } else if (e instanceof Prisma.PrismaClientValidationError) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'UNEXPECTED_INPUT',
          },
          HttpStatus.BAD_REQUEST,
        );
      } else {
        throw new HttpException(
          {
            status: HttpStatus.INTERNAL_SERVER_ERROR,
            error: 'SERVER_ERROR',
          },
          HttpStatus.INTERNAL_SERVER_ERROR,
        );
      }
    }
  }

  @Delete(':id')
  @HttpCode(200)
  @UseGuards(serviceAdminGuard)
  @ApiOperation({
    summary: 'Delete user at the service admin level by user ID.',
  })
  @ApiBody({
    description: 'Delete user with sevice admin level by user ID',
    type: DeleteUserBodyDto,
  })
  @ApiResponse({ status: 200, description: 'ok', type: UserResponseDto })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
    type: DefaultFailedDto,
  })
  @ApiResponse({
    status: 500,
    description: 'Server Error',
    type: DefaultFailedDto,
  })
  @ApiCookieAuth()
  async deleteUser(@Param('id') _id: string): Promise<UserResponseDto> {
    if (!_id || isStringObject(_id)) {
      throw new HttpException(
        {
          status: HttpStatus.BAD_REQUEST,
          error: 'UNEXPECTED_INPUT',
        },
        HttpStatus.BAD_REQUEST,
      );
    }
    try {
      const result = await this.userService.deleteUser({
        userId: _id,
      });
      if (result instanceof Error) throw result;
      return result;
    } catch (e) {
      if (
        e instanceof Prisma.PrismaClientKnownRequestError ||
        e instanceof Prisma.PrismaClientValidationError
      ) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'CANNOT_DELETE_TABLE',
          },
          HttpStatus.BAD_REQUEST,
        );
      } else {
        throw new HttpException(
          {
            status: HttpStatus.INTERNAL_SERVER_ERROR,
            error: 'SERVER_ERROR',
          },
          HttpStatus.INTERNAL_SERVER_ERROR,
        );
      }
    }
  }
}
