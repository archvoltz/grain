import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { APIKeyService } from 'src/apiKey/apiKey.service';

@Injectable()
export class ApikeyGuard extends AuthGuard('api-key') implements CanActivate {
  constructor(private apikeyService: APIKeyService) {
    super();
  }
  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest<Request>();
    const key = request.headers['f8-api-key'];
    if (!key) return false;
    const apikey = await this.apikeyService
      .getApiKey({
        where: {
          key: key,
        },
        select: {
          isActive: true,
        },
      })
      .catch(() => null);
    if (!apikey || apikey instanceof Error || !apikey.isActive) return false;
    return super.canActivate(context) as boolean;
  }
}
