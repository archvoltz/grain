import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { APIKeyService } from 'src/apiKey/apiKey.service';
import { ProjectService } from 'src/project/project.service';

@Injectable()
export class ApikeyAddressGuard
  extends AuthGuard('api-key')
  implements CanActivate
{
  constructor(
    private apikeyService: APIKeyService,
    private projectService: ProjectService,
  ) {
    super();
  }
  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest<Request>();
    const key = request.headers['f8-api-key'];
    if (!key) return false;
    const validate = await super.canActivate(context);
    if (!validate) return false;
    const apikey = await this.apikeyService
      .getApiKey({
        where: {
          key: key,
          isActive: true,
        },
      })
      .catch(() => null);
    if (!apikey || apikey instanceof Error) return false;
    const target = await this.projectService
      .getProjectById({
        where: {
          projectId: apikey.projectId,
        },
        include: {
          contract: {
            select: {
              address: true,
            },
          },
        },
      })
      .catch(() => null);
    if (!target?.contract) return false;
    const body = JSON.parse(JSON.stringify(request.body));
    const result = target.contract.some(
      (item) => item.address == body.contractAddress,
    );
    return result;
  }
}
