import { Module } from '@nestjs/common';
import { ApikeyAddressGuard } from './apikey-address.guard';
import { ApikeyGuard } from './apikey.guard';
import { projectAdminGuard } from './project-admin.guard';
import { projectMemberGuard } from './project-member.guard';
import { serviceAdminGuard } from './service-admin.guard';
import { userOwnGuard } from './user-own.guard';
import { ApiKeyAddressStrategy } from 'src/strategy/apikey-address.strategy';
import { ApiKeyStrategy } from 'src/strategy/apiKey.strategy';
import { ProjectService } from 'src/project/project.service';
import { AuthService } from 'src/auth/auth.service';
import { UserService } from 'src/user/user.service';
import { PrismaService } from 'src/prisma.service';
import { RedisService } from 'src/redis/redis.service';
import { HashService } from 'src/hash.service';
import { APIKeyService } from 'src/apiKey/apiKey.service';
import { ApiLimitGuard } from './api-limit.guard';
import { SharedModule } from 'src/shared.module';

@Module({
  providers: [
    ApikeyAddressGuard,
    ApikeyGuard,
    projectAdminGuard,
    projectMemberGuard,
    serviceAdminGuard,
    userOwnGuard,
    ApiKeyStrategy,
    ApiKeyAddressStrategy,
    UserService,
    AuthService,
    ProjectService,
    PrismaService,
    RedisService,
    HashService,
    APIKeyService,
    ApiLimitGuard,
  ],
  imports: [SharedModule],
  exports: [
    ApikeyAddressGuard,
    ApikeyGuard,
    projectAdminGuard,
    projectMemberGuard,
    serviceAdminGuard,
    userOwnGuard,
    ApiKeyStrategy,
    ApiKeyAddressStrategy,
    ApiLimitGuard,
  ],
})
export class GuardsModule {}
