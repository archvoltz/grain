import { ForbiddenException, Injectable, Logger } from '@nestjs/common';
import { PrismaService } from 'src/prisma.service';
import { APIKey, Prisma } from '../generated/prisma/client';

@Injectable()
export class APIKeyService {
  constructor(
    private prisma: PrismaService,
    private readonly logger: Logger,
  ) {}

  async createApiKey(data: Prisma.APIKeyCreateInput): Promise<APIKey> {
    try {
      const result = await this.prisma.aPIKey.create({
        data,
      });

      this.logger.log(
        `api key created: id=${result?.id} project=${result?.projectId}`,
        'APIKeyService',
      );
      return result;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `createApiKey failed: ${err.message}`,
        err,
        'APIKeyService',
      );
      throw e;
    }
  }

  async getApiKey(params: {
    where: Prisma.APIKeyWhereUniqueInput;
    select?: Prisma.APIKeySelect;
  }): Promise<APIKey> {
    const { where, select } = params;
    try {
      const result = await this.prisma.aPIKey.findUnique({
        where,
        select,
      });

      if (!result) {
        this.logger.warn('api key not found', 'APIKeyService');
      }
      return result;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `getApiKey failed: ${err.message}`,
        err,
        'APIKeyService',
      );
      throw e;
    }
  }

  async getApiKeyWithProjectAndRole(where: Prisma.APIKeyWhereUniqueInput) {
    const result = await this.prisma.aPIKey.findUnique({
      where,
      include: {
        project: {
          include: {
            userOnProject: {
              include: {
                role: true,
              },
            },
          },
        },
      },
    });
    if (!result) {
      this.logger.warn('api key not found (limit 判定)', 'APIKeyService');
    }
    return result;
  }

  async updateApiKey(params: {
    where: Prisma.APIKeyWhereUniqueInput;
    data: Prisma.APIKeyUpdateInput;
  }): Promise<APIKey> {
    const { where, data } = params;
    try {
      const result = await this.prisma.aPIKey.update({
        where,
        data,
      });
      this.logger.debug(`api key updated: id=${result?.id}`, 'APIKeyService');
      return result;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `updateApiKey failed: ${err.message}`,
        err,
        'APIKeyService',
      );
      throw e;
    }
  }

  async deleteApiKey(params: {
    where: Prisma.APIKeyWhereUniqueInput;
  }): Promise<APIKey> {
    const { where } = params;
    try {
      const result = await this.prisma.aPIKey.delete({
        where,
      });
      this.logger.log(`api key deleted: id=${result?.id}`, 'APIKeyService');
      return result;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `deleteApiKey failed: ${err.message}`,
        err,
        'APIKeyService',
      );
      throw e;
    }
  }

  async checkRateLimit(apiKeyId: string): Promise<void> {
    const apiKey = await this.prisma.aPIKey.findUnique({
      where: { id: Number(apiKeyId) },
    });

    if (!apiKey) {
      this.logger.warn(
        `rate limit check: api key not found id=${apiKeyId}`,
        'APIKeyService',
      );
      throw new ForbiddenException('API key not found');
    }

    if (
      typeof apiKey.limit === 'number' &&
      apiKey.requestCount >= apiKey.limit
    ) {
      this.logger.warn(
        `rate limit exceeded: id=${apiKey.id} count=${apiKey.requestCount} limit=${apiKey.limit}`,
        'APIKeyService',
      );
      throw new ForbiddenException('API rate limit exceeded');
    }

    await this.prisma.aPIKey.update({
      where: { id: Number(apiKeyId) },
      data: {
        requestCount: { increment: 1 },
      },
    });
  }
}
