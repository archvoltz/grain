import { Injectable, Logger } from '@nestjs/common';
import { Prisma, Tag } from '../generated/prisma/client';
import { PrismaService } from 'src/prisma.service';

@Injectable()
export class TagService {
  constructor(
    private prisma: PrismaService,
    private readonly logger: Logger,
  ) {}

  async createTag(_newTag: Prisma.TagCreateInput): Promise<string | Tag> {
    try {
      const res = await this.prisma.tag.create({ data: _newTag });
      this.logger.debug(`tag created: ${res?.tagId}`, 'TagService');
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(`createTag failed: ${err.message}`, err, 'TagService');
      throw e;
    }
  }

  async getAllTags(): Promise<Tag[]> {
    try {
      const res = await this.prisma.tag.findMany();
      this.logger.debug(`tags in total: ${res.length}`, 'TagService');
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(`getAllTags failed: ${err.message}`, err, 'TagService');
      throw e;
    }
  }

  async getTagById(_tagId: Prisma.TagWhereUniqueInput): Promise<Tag> {
    try {
      const res = await this.prisma.tag.findUnique({
        where: _tagId,
        select: {
          tagId: true,
          name: true,
          type: true,
          description: true,
        },
      });

      if (!res) {
        this.logger.warn(
          `tag not found: ${String(_tagId?.tagId)}`,
          'TagService',
        );
      }
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(`getTagById failed: ${err.message}`, err, 'TagService');
      throw e;
    }
  }

  async updateTag(params: {
    where: Prisma.TagWhereUniqueInput;
    data: Prisma.TagUpdateInput;
  }): Promise<Tag> {
    const { where, data } = params;
    try {
      const res = await this.prisma.tag.update({
        where,
        data,
        select: {
          tagId: true,
          name: true,
          type: true,
          description: true,
        },
      });
      this.logger.debug(`tag updated: ${res?.tagId}`, 'TagService');
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(`updateTag failed: ${err.message}`, err, 'TagService');
      throw e;
    }
  }

  async deleteTag(where: Prisma.TagWhereUniqueInput): Promise<any> {
    try {
      const res = await this.prisma.tag.delete({
        where,
        select: {
          tagId: true,
          name: true,
          type: true,
          description: true,
        },
      });

      this.logger.log(`tag deleted: ${res?.tagId}`, 'TagService');
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(`deleteTag failed: ${err.message}`, err, 'TagService');
      throw e;
    }
  }
}
