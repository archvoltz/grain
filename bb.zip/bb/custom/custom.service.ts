import { Injectable, Logger } from '@nestjs/common';
import { ethers } from 'ethers';

@Injectable()
export class CustomService {
  constructor(private readonly logger: Logger) {}

  getTokenId(_txReceipt: ethers.TransactionReceipt): number {
    const transferEventHash =
      '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef';
    const logs = _txReceipt.logs;
    const transferEvent = logs.find(
      (res) => res.topics[0] === transferEventHash,
    ) as ethers.Log;

    if (!transferEvent) {
      this.logger.error(
        `no Transfer event in tx=${_txReceipt?.hash} (logs=${logs.length})`,
        'CustomService',
      );
    }
    const tokenIdHex = transferEvent.topics[3];
    const num = BigInt(tokenIdHex);
    return Number(num);
  }

  isTransactionReceipt(
    tx_receipt:
      | ethers.TransactionReceipt
      | ethers.ContractTransactionResponse
      | Error,
  ): tx_receipt is ethers.TransactionReceipt {
    return 'status' in tx_receipt && 'blockNumber' in tx_receipt;
  }
}
