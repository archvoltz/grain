import {
  Controller,
  Post,
  Body,
  UseGuards,
  Req,
  HttpCode,
  HttpException,
  HttpStatus,
  Param,
  Logger,
} from '@nestjs/common';
import { Web3Service } from './web3.service';
import { ProjectContractService } from 'src/projectContract/projectcontract.service';
import { Web3Dto, Web3DeployDto } from 'src/dto/web3.dto';
import { Prisma } from '../generated/prisma/client';
import { APIKeyService } from 'src/apiKey/apiKey.service';

import {
  ApiBody,
  ApiCookieAuth,
  ApiExcludeEndpoint,
  ApiOperation,
  ApiResponse,
  ApiSecurity,
} from '@nestjs/swagger';
import { ApikeyAddressGuard } from 'src/guards/apikey-address.guard';
import { ApikeyGuard } from 'src/guards/apikey.guard';
import { DefaultFailedDto } from 'src/dto/auth.dto';
import { ProjectContractTableDto } from 'src/dto/smartContract.dto';
import { projectAdminGuard } from 'src/guards/project-admin.guard';
import { UseInterceptors } from '@nestjs/common';
import { IncreaseRequestCountInterceptor } from 'src/interceptors/increaseRequestCount.interceptor';
import { ApiLimitGuard } from 'src/guards/api-limit.guard';

@Controller('f8')
@UseInterceptors(IncreaseRequestCountInterceptor)
export class Web3Controller {
  constructor(
    private readonly web3Service: Web3Service,
    private readonly apiKeyService: APIKeyService,
    private readonly projectContractService: ProjectContractService,
    private readonly logger: Logger,
  ) {}

  @Post()
  @HttpCode(200)
  @ApiSecurity('api-key')
  @ApiSecurity('api-secret')
  @ApiOperation({
    summary:
      'Execute the function of the deployed smart contract with the API keys.',
  })
  @ApiResponse({ status: 200, description: 'ok' })
  @ApiResponse({
    status: 500,
    description: 'Server Error',
    type: DefaultFailedDto,
  })
  @ApiBody({ type: Web3Dto })
  @UseGuards(ApikeyAddressGuard, ApiLimitGuard)
  async execute(
    @Body()
    body: Web3Dto,
  ): Promise<any> {
    try {
      const result = await this.web3Service.execute(body);
      if (result instanceof Error) {
        throw new HttpException(
          {
            status: HttpStatus.INTERNAL_SERVER_ERROR,
            error: 'SERVER_ERROR',
          },
          HttpStatus.INTERNAL_SERVER_ERROR,
        );
      }
      return result;
    } catch (e) {
      this.logger.error(
        'Failed to execute contract',
        e,
        `${Web3Controller.name}#execute`,
      );
      throw new HttpException(
        {
          status: HttpStatus.INTERNAL_SERVER_ERROR,
          error: 'SERVER_ERROR',
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Post('deploy')
  @HttpCode(201)
  @ApiSecurity('api-key')
  @ApiSecurity('api-secret')
  @ApiOperation({
    summary: 'Deploy smart contract into WEB3.0 network with the API keys.',
  })
  @ApiResponse({
    status: 201,
    description: 'Created',
    type: ProjectContractTableDto,
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
    type: DefaultFailedDto,
  })
  @ApiResponse({
    status: 401,
    description: 'Unauthorized',
    type: DefaultFailedDto,
  })
  @ApiResponse({
    status: 500,
    description: 'Server error',
    type: DefaultFailedDto,
  })
  @ApiBody({ type: Web3DeployDto })
  @UseGuards(ApikeyGuard, ApiLimitGuard)
  async deployWithApiKey(
    @Body()
    body: Web3DeployDto,
    @Req()
    req: Request,
  ): Promise<any> {
    try {
      const result = await this.web3Service.deploy(body);

      if (result instanceof Error) throw result;

      let target;
      try {
        target = await this.apiKeyService.getApiKey({
          where: {
            key: req.headers['f8-api-key'],
          },
        });
      } catch (e) {
        throw new HttpException(
          {
            status: HttpStatus.UNAUTHORIZED,
            error: 'UNAUTHORISED_ACCESS',
          },
          HttpStatus.UNAUTHORIZED,
        );
      }
      const projectId = target.projectId;
      let name = await this.web3Service.getContractName(
        result.contractAddress,
        body.chainId,
      );
      if (typeof name != 'string') name = '';
      const data: Prisma.ProjectContractCreateInput = {
        name: name,
        chainId: parseInt(body.chainId),
        address: result.contractAddress,
        description: 'This is the contract created with f8 Web3.0 API',
        contract: {
          connect: {
            contractId: body.contractId,
          },
        },
        project: {
          connect: {
            projectId: projectId,
          },
        },
      };
      const create =
        await this.projectContractService.createProjectContract(data);
      return create;
    } catch (e) {
      this.logger.error(
        'Failed to deploy contract',
        e,
        `${Web3Controller.name}#deployWithApiKey`,
      );
      if (
        e instanceof Prisma.PrismaClientKnownRequestError ||
        e instanceof Prisma.PrismaClientValidationError
      ) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'UNEXPECTED_INPUT',
          },
          HttpStatus.BAD_REQUEST,
        );
      } else {
        throw new HttpException(
          {
            status: HttpStatus.INTERNAL_SERVER_ERROR,
            error: 'SERVER_ERROR',
          },
          HttpStatus.INTERNAL_SERVER_ERROR,
        );
      }
    }
  }

  @Post('deploy/:id')
  @ApiExcludeEndpoint()
  @HttpCode(201)
  @ApiCookieAuth()
  @ApiOperation({
    summary: 'Deploy smart contract into WEB3.0 network with the API keys.',
  })
  @ApiResponse({
    status: 201,
    description: 'Deployed',
    type: ProjectContractTableDto,
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request',
    type: DefaultFailedDto,
  })
  @ApiResponse({
    status: 401,
    description: 'Unauthorized',
    type: DefaultFailedDto,
  })
  @ApiResponse({
    status: 500,
    description: 'Server error',
    type: DefaultFailedDto,
  })
  @ApiBody({ type: Web3DeployDto })
  @UseGuards(projectAdminGuard)
  async deployWithId(
    @Param('id')
    projectId: string,
    @Body()
    body: Web3DeployDto,
  ): Promise<any> {
    try {
      const result = await this.web3Service.deploy(body);

      if (result instanceof Error) throw result;

      let name = await this.web3Service.getContractName(
        result.contractAddress,
        body.chainId,
      );
      if (typeof name != 'string') name = '';
      const data: Prisma.ProjectContractCreateInput = {
        name: name,
        chainId: parseInt(body.chainId),
        address: result.contractAddress,
        description: 'This is the contract created with f8 Web3.0 API',
        contract: {
          connect: {
            contractId: body.contractId,
          },
        },
        project: {
          connect: {
            projectId: projectId,
          },
        },
      };
      const create =
        await this.projectContractService.createProjectContract(data);
      return create;
    } catch (e) {
      this.logger.error(
        'Failed to deploy contract with Id',
        e,
        `${Web3Controller.name}#deployWithId`,
      );
      if (
        e instanceof Prisma.PrismaClientKnownRequestError ||
        e instanceof Prisma.PrismaClientValidationError
      ) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'UNEXPECTED_INPUT',
          },
          HttpStatus.BAD_REQUEST,
        );
      } else {
        throw new HttpException(
          {
            status: HttpStatus.INTERNAL_SERVER_ERROR,
            error: 'SERVER_ERROR',
          },
          HttpStatus.INTERNAL_SERVER_ERROR,
        );
      }
    }
  }
}
