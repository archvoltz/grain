import { Inject, Injectable } from '@nestjs/common';
import { PrismaService } from 'src/prisma.service';
import { Project, Prisma } from '../generated/prisma/client';
import { APP_LOGGER } from '../logger/app-logger';
import type { AppLogger } from '../logger/app-logger';

@Injectable()
export class ProjectService {
  constructor(
    private prisma: PrismaService,
    @Inject(APP_LOGGER) private readonly logger: AppLogger,
  ) {}

  async createProject(data: Prisma.ProjectCreateInput): Promise<Project> {
    try {
      const result = await this.prisma.project.create({
        data,
      });
      this.logger.log(
        `project created: ${result?.projectId}`,
        'ProjectService',
      );
      return result;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `createProject failed: ${err.message}`,
        err,
        'ProjectService',
      );
      throw e;
    }
  }
  async getProjectById(params: {
    where: Prisma.ProjectWhereUniqueInput;
    select?: Prisma.ProjectSelect;
    include?: Prisma.ProjectInclude;
  }): Promise<Project | any> {
    const { where, select, include } = params;
    if (select && include) {
      const data = await this.prisma.project.findUnique({
        where,
        include,
      });
      const include_true = Object.keys(select).filter(
        (key) => select[key] === true,
      );
      const result = new Object();
      include_true.forEach((key) => {
        result[key] = data[key];
      });
      return result;
    } else if (include) {
      return await this.prisma.project.findUnique({
        where,
        include,
      });
    } else if (select) {
      return await this.prisma.project.findUnique({
        where,
        select,
      });
    } else {
      const result = await this.prisma.project.findUnique({
        where,
      });
      // 見つからないのはクエリとしては成功なので拡張からは見えない。
      if (!result) {
        this.logger.warn(
          `project not found: ${String(where?.projectId)}`,
          'ProjectService',
        );
      }
      return result;
    }
  }

  async getProjects(params: {
    skip?: number;
    take?: number;
    select?: Prisma.ProjectSelect;
    cursor?: Prisma.ProjectWhereUniqueInput;
    where?: Prisma.ProjectWhereUniqueInput;
    orderBy?: Prisma.ProjectOrderByWithRelationInput;
  }): Promise<Project[]> {
    try {
      const { skip, take, cursor, where, orderBy, select } = params;
      const result = await this.prisma.project.findMany({
        skip,
        take,
        cursor,
        where,
        orderBy,
        select,
      });
      this.logger.debug(`projects fetched: ${result.length}`, 'ProjectService');
      return result;
    } catch (error) {
      const err = error instanceof Error ? error : new Error(String(error));
      this.logger.error(
        `getProjects failed: ${err.message}`,
        err,
        'ProjectService',
      );
      throw error;
    }
  }

  async updateProject(params: {
    where: Prisma.ProjectWhereUniqueInput;
    data: Prisma.ProjectUpdateInput;
  }): Promise<Project> {
    try {
      const { where, data } = params;
      const result = await this.prisma.project.update({
        where,
        data,
      });
      this.logger.debug(
        `project updated: ${result?.projectId}`,
        'ProjectService',
      );
      return result;
    } catch (error) {
      const err = error instanceof Error ? error : new Error(String(error));
      this.logger.error(
        `updateProject failed: ${err.message}`,
        err,
        'ProjectService',
      );
      throw error;
    }
  }

  async deleteProject(where: Prisma.ProjectWhereUniqueInput): Promise<Project> {
    try {
      const result = await this.prisma.project.delete({
        where,
      });
      // プロジェクト削除は紐づくコントラクトごと使えなくなる。INFO で残す。
      this.logger.log(
        `project deleted: ${result?.projectId}`,
        'ProjectService',
      );
      return result;
    } catch (error) {
      const err = error instanceof Error ? error : new Error(String(error));
      this.logger.error(
        `deleteProject failed: ${err.message}`,
        err,
        'ProjectService',
      );
      throw error;
    }
  }
}
