import { Inject, Injectable } from '@nestjs/common';
import * as bcrypt from 'bcryptjs';
import { APP_LOGGER } from './logger/app-logger';
import type { AppLogger } from './logger/app-logger';

@Injectable()
export class HashService {
  constructor(@Inject(APP_LOGGER) private readonly logger: AppLogger) {}
  makeHash = async (_traget: string, _salt: string) => {
    try {
      const hashedPassword = await bcrypt.hash(_traget, _salt);
      return hashedPassword;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(`makeHash failed: ${err.message}`, err, 'HashService');
      return e;
    }
  };

  checkPassword = async (_target: string, _userInput: string) => {
    try {
      const result = await bcrypt.compare(_userInput, _target);
      return result;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      // false は「パスワード不一致」と同じ戻り値なので、ここを黙らせると
      // ハッシュが壊れている / salt が不正でも「認証失敗」に見えてしまう。
      this.logger.error(
        `checkPassword failed: ${err.message}`,
        err,
        'HashService',
      );
      return false;
    }
  };
}
