import { Inject, Injectable } from '@nestjs/common';
import { SmartContract, Prisma } from '../generated/prisma/client';
import { PrismaService } from 'src/prisma.service';
import { APP_LOGGER } from '../logger/app-logger';
import type { AppLogger } from '../logger/app-logger';

@Injectable()
export class SmartContractService {
  constructor(
    private prisma: PrismaService,
    @Inject(APP_LOGGER) private readonly logger: AppLogger,
  ) {}

  async createContract(
    _newSmartContract: Prisma.SmartContractCreateInput,
  ): Promise<string | SmartContract> {
    try {
      const res = await this.prisma.smartContract.create({
        data: _newSmartContract,
      });
      this.logger.log(
        `contract created: ${res?.contractId}`,
        'SmartContractService',
      );
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `createContract failed: ${err.message}`,
        err,
        'SmartContractService',
      );
      throw e;
    }
  }

  // async getAllContracts(): Promise<SmartContract[]> {
  //   try {
  //     const res = this.prisma.smartContract.findMany();
  //     return res;
  //   } catch (e) {
  //     return e;
  //   }
  // }

  async getContracts(params: {
    skip?: number;
    take?: number;
    cursor?: Prisma.SmartContractWhereUniqueInput;
    where?: Prisma.SmartContractWhereInput;
    orderBy?: Prisma.SmartContractOrderByWithRelationInput;
    include?: Prisma.SmartContractInclude;
  }): Promise<SmartContract[]> {
    const { skip, take, cursor, where, orderBy, include } = params;
    try {
      const res = await this.prisma.smartContract.findMany({
        skip,
        take,
        cursor,
        where,
        orderBy,
        include,
      });
      this.logger.debug(
        `contracts fetched: ${res.length}`,
        'SmartContractService',
      );
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `getContracts failed: ${err.message}`,
        err,
        'SmartContractService',
      );
      return e;
    }
  }

  async getContractById(
    _targetId: Prisma.SmartContractWhereUniqueInput,
  ): Promise<SmartContract> {
    try {
      const res = await this.prisma.smartContract.findUnique({
        where: _targetId,
        include: {
          tag: true,
        },
      });
      // 見つからないのはクエリとしては成功なので拡張からは見えない。
      if (!res) {
        this.logger.warn(
          `contract not found: ${String(_targetId?.contractId)}`,
          'SmartContractService',
        );
      }
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `getContractById failed: ${err.message}`,
        err,
        'SmartContractService',
      );
      return e;
    }
  }

  async updateContract(params: {
    where: Prisma.SmartContractWhereUniqueInput;
    data: Prisma.SmartContractUpdateInput;
  }): Promise<SmartContract> {
    const { where, data } = params;
    try {
      const res = await this.prisma.smartContract.update({
        where,
        data,
      });
      this.logger.debug(
        `contract updated: ${res?.contractId}`,
        'SmartContractService',
      );
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `updateContract failed: ${err.message}`,
        err,
        'SmartContractService',
      );
      throw e;
    }
  }

  async deleteContract(
    where: Prisma.SmartContractWhereUniqueInput,
  ): Promise<SmartContract> {
    try {
      const res = await this.prisma.smartContract.delete({
        where,
      });
      // 削除するとそのコントラクトは API から呼べなくなる。INFO で残す。
      this.logger.log(
        `contract deleted: ${res?.contractId}`,
        'SmartContractService',
      );
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `deleteContract failed: ${err.message}`,
        err,
        'SmartContractService',
      );
      throw e;
    }
  }
}
