import { Inject, Injectable } from '@nestjs/common';
import { PrismaService } from 'src/prisma.service';
import { APP_LOGGER } from '../logger/app-logger';
import type { AppLogger } from '../logger/app-logger';
import { Prisma } from '../generated/prisma/client';

@Injectable()
export class UserService {
  constructor(
    private prisma: PrismaService,
    @Inject(APP_LOGGER) private readonly logger: AppLogger,
  ) {}

  async createNewUser(params: {
    data: Prisma.UserCreateInput;
    select?: Prisma.UserSelect;
  }): Promise<any> {
    const { data, select } = params;
    try {
      const res = await this.prisma.user.create({
        data: data,
        select: select,
      });

      this.logger.debug(`user created: ${res?.userId}`, 'UserService');
      return res;
    } catch (e) {
      // 第 2 引数は **Error オブジェクトそのもの**。e.stack (string) を渡すと
      // isStackFormat の正規表現がほぼ通らず、stack が error.stack に入らずに
      // 2 行目の message として出てしまう (1 件 1 行が崩れる)。
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `createNewUser failed: ${err.message}`,
        err,
        'UserService',
      );
      return e;
    }
  }

  async getAllUsers(): Promise<any> {
    const res = await this.prisma.user.findMany({
      select: {
        userId: true,
        name: true,
        role: true,
      },
    });

    this.logger.debug(`users in total: ${res.length}`, 'UserService');
    return res;
  }
  catch(e) {
    return e;
  }

  async getusers(params: {
    skip?: number;
    take?: number;
    cursor?: Prisma.UserWhereUniqueInput;
    where?: Prisma.UserWhereUniqueInput;
    orderBy?: Prisma.UserOrderByWithRelationInput;
  }): Promise<any> {
    const { skip, take, cursor, where, orderBy } = params;
    try {
      const res = await this.prisma.user.findMany({
        skip,
        take,
        cursor,
        where,
        orderBy,
        select: {
          userId: true,
          name: true,
          role: true,
        },
      });

      // DEBUG。本番の severities から debug を外せば、この行だけが
      // 出力ごと消える (呼び出し側は触らない)。
      this.logger.debug(`users fetched: ${res.length}`, 'UserService');
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(`getusers failed: ${err.message}`, err, 'UserService');
      return e;
    }
  }

  async getUserById(_userId: Prisma.UserWhereUniqueInput): Promise<any> {
    try {
      const res = await this.prisma.user.findUnique({
        where: _userId,
        select: {
          userId: true,
          name: true,
          role: true,
        },
      });
      return res;
    } catch (e) {
      return e;
    }
  }

  async getUserByName(_name: Prisma.UserWhereUniqueInput): Promise<any> {
    try {
      const res = await this.prisma.user.findUnique({
        where: _name,
        select: {
          userId: true,
          name: true,
          role: true,
          password: true,
        },
      });

      // WARN。「異常ではないが後で数えたいもの」に使う。
      // 4xx 相当の失敗を ERROR で出すとアラートが鳴りすぎるので、
      // アクセスログの severityFromStatus と同じ温度感で合わせる。
      if (!res) {
        this.logger.warn(
          `user not found by name: ${String(_name?.name)}`,
          'UserService',
        );
      }
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `getUserByName failed: ${err.message}`,
        err,
        'UserService',
      );
      return e;
    }
  }

  async updateUser(params: {
    where: Prisma.UserWhereUniqueInput;
    data: Prisma.UserUpdateInput;
  }): Promise<any> {
    const { where, data } = params;
    try {
      const res = await this.prisma.user.update({
        where,
        data,
        select: {
          userId: true,
          name: true,
          role: true,
        },
      });
      return res;
    } catch (e) {
      // 第 1 引数は **文字列** にする。共通ログ行は文字列でないものを
      // JSON.stringify(message) で畳むので、Error をそのまま渡すと
      // message が "{}" になって肝心の文言が消える。
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `updateUser failed: ${err.message}`,
        err,
        'UserService',
      );
      return e;
    }
  }

  async deleteUser(where: Prisma.UserWhereUniqueInput): Promise<any> {
    try {
      const res = this.prisma.user.delete({
        where,
        select: {
          userId: true,
          name: true,
          role: true,
        },
      });
      return res;
    } catch (e) {
      return e;
    }
  }
}
