import { Inject, Injectable, UnauthorizedException } from '@nestjs/common';
import { Prisma } from '../generated/prisma/client';
import { APIKeyService } from 'src/apiKey/apiKey.service';
import { HashService } from 'src/hash.service';
import { ProjectService } from 'src/project/project.service';
import { UserService } from 'src/user/user.service';
import { APP_LOGGER } from '../logger/app-logger';
import type { AppLogger } from '../logger/app-logger';

@Injectable()
export class AuthService {
  constructor(
    private hashService: HashService,
    private apikeyService: APIKeyService,
    private projectService: ProjectService,
    private userService: UserService,
    @Inject(APP_LOGGER) private readonly logger: AppLogger,
  ) {}

  async validateApiKey(_key: string): Promise<boolean> {
    try {
      const apikey = await this.apikeyService.getApiKey({
        where: {
          key: _key,
        },
      });
      if (apikey instanceof Error) throw new UnauthorizedException();
      const result = await this.projectService.getProjectById({
        where: {
          projectId: apikey.projectId,
        },
      });
      if (result.length != 0) {
        return true;
      } else {
        this.logger.warn(
          `api key has no project: project=${apikey?.projectId}`,
          'AuthService',
        );
        return false;
      }
    } catch (e) {
      // **ここは全部 false に丸まる**ので、何も出さないと「キーが違う」と
      // 「DB が落ちている」の区別が付かない。認証の失敗は WARN、それ以外
      // (想定外の例外) は ERROR に分ける。
      if (e instanceof UnauthorizedException) {
        this.logger.warn('api key validation failed', 'AuthService');
      } else {
        const err = e instanceof Error ? e : new Error(String(e));
        this.logger.error(
          `validateApiKey failed: ${err.message}`,
          err,
          'AuthService',
        );
      }
      return false;
    }
  }

  async validateHashedApikey(_key: string, _secretKey: string) {
    // service は今「失敗を戻り値で返す」規約だが throw へ移行中
    // (docs/logging-implementation.md の Stage 1)。throw が素通りすると 401 が 500 に
    // 化けるので、どちらで来ても UnauthorizedException にそろえる。
    const apikey = await this.apikeyService
      .getApiKey({
        where: {
          key: _key,
        },
      })
      .catch(() => null);
    if (!apikey || apikey instanceof Error) throw new UnauthorizedException();
    const valid = await this.hashService.checkPassword(
      apikey.secret,
      _secretKey,
    );

    // secret の不一致。401 と同じ温度感なので WARN (値そのものは出さない)。
    if (!valid) {
      this.logger.warn('api secret mismatch', 'AuthService');
    }
    return valid;
  }

  async getPasswordByName(_name: Prisma.UserWhereUniqueInput): Promise<any> {
    const res = await this.userService.getUserByName(_name);
    return res;
  }
}
