import { ConfigService } from '@nestjs/config';
import { Inject, Injectable, OnModuleInit } from '@nestjs/common';
import { ethers } from 'ethers';
import { SmartContractService } from '../SmartContract/SmartContract.service';
import {
  SecretsManager,
  GetSecretValueCommand,
} from '@aws-sdk/client-secrets-manager';
import { APP_LOGGER } from '../logger/app-logger';
import type { AppLogger } from '../logger/app-logger';

export interface web3DeployRPC {
  contractId: number;
  chainId: string;
  inputs: any[];
  value?: string;
}
export interface web3RPC {
  chainId: string;
  contractAddress: string;
  method: string;
  abi: object[];
  inputs: any[];
  value?: string;
}

interface NetworkConfig {
  name: string;
  rpcUrl: string;
}

interface RpcProviders {
  [id: number]: NetworkConfig;
}

interface ProviderMap {
  [id: number]: AutoGasSuggestProvider;
}

type Method = {
  method: string;
  abi: ethers.InterfaceAbi;
  contractAddress: string;
  wallet: ethers.Wallet;
  callLimit?: number;
};

const BASE_DELAY = 500;

@Injectable()
export class Web3Service implements OnModuleInit {
  private providers: ProviderMap = {};
  private wallet: ethers.Wallet;
  private rpcProviders: RpcProviders;
  constructor(
    private readonly configService: ConfigService,
    private readonly smartContractService: SmartContractService,
    @Inject(APP_LOGGER) private readonly logger: AppLogger,
  ) {}

  async onModuleInit() {
    this.updateChains();
    await this.updateProvider();
  }

  private updateChains() {
    this.rpcProviders = {
      137: {
        name: 'Polygon',
        rpcUrl: this.configService.get<string>('RPC_NODE'),
      },
      11155111: {
        name: 'Sepolia',
        rpcUrl: this.configService.get<string>('RPC_NODE_SEPOLIA'),
      },
      1337: {
        name: 'Ganache',
        rpcUrl: this.configService.get<string>('RPC_NODE_GANACHE'),
      },
    };
  }
  private async updateProvider() {
    let secretKey;
    if (this.configService.get<string>('AWS_SECRET')) {
      secretKey = await this.getSecretKey(
        this.configService.get<string>('AWS_SECRET'),
      );
    } else {
      secretKey = this.configService.get<string>('SECRET_KEY');
    }
    try {
      for (const [chainId, network] of Object.entries(this.rpcProviders)) {
        if (network.rpcUrl) {
          this.providers[Number(chainId)] = new AutoGasSuggestProvider(
            network.rpcUrl,
          );
        }
      }
      this.wallet = new ethers.Wallet(secretKey, this.providers[137]);

      this.logger.debug(
        `providers ready: ${Object.keys(this.providers).join(', ') || '(none)'}`,
        Web3Service.name,
      );
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      // ここで失敗すると wallet が未初期化のまま起動し、最初の execute で
      // 落ちる。原因が遠くなるので必ず残す。
      this.logger.error(
        `updateProvider failed: ${err.message}`,
        err,
        Web3Service.name,
      );
      return e;
    }
  }

  async execute(data: web3RPC) {
    // Error を **戻り値** で返すので、拡張にもアクセスログにも出ない。
    // 設定漏れか呼び出し側の指定ミスのどちらかなので WARN で残す。
    if (!this.providers[Number(data.chainId)]) {
      this.logger.warn(
        `unsupported chain: ${data.chainId} (method=${data.method})`,
        Web3Service.name,
      );
      return new Error('Unsupported blockchains');
    }
    this.wallet = this.wallet.connect(this.providers[Number(data.chainId)]);
    try {
      const executeMethod = this._execute({
        contractAddress: data.contractAddress,
        wallet: this.wallet,
        method: data.method,
        abi: data.abi,
        callLimit: 5,
      })(...data.inputs);
      const result = await executeMethod(0);
      this.logger.debug(
        `executed ${data.method} on ${data.contractAddress} chain=${data.chainId}`,
        Web3Service.name,
      );
      return result;
    } catch (error) {
      this.logger.error(
        'Failed to execute contract',
        error,
        'ContractExecution',
      );
      throw error;
    }
  }

  async deploy(data: web3DeployRPC) {
    if (!this.providers[Number(data.chainId)]) {
      this.logger.warn(
        `unsupported chain: ${data.chainId} (deploy contractId=${data.contractId})`,
        Web3Service.name,
      );
      return new Error('Unsupported blockchains');
    }
    this.wallet = this.wallet.connect(this.providers[Number(data.chainId)]);
    try {
      const contractInfo = await this.smartContractService.getContractById({
        contractId: data.contractId,
      });
      const factory = new ethers.ContractFactory(
        contractInfo.abi as ethers.InterfaceAbi,
        contractInfo.bytecode,
        this.wallet,
      );
      const contract = await factory.deploy(...data.inputs);
      await contract.waitForDeployment();
      const transaction: ethers.ContractTransactionResponse =
        await contract.deploymentTransaction();
      const txHash = transaction.hash;
      const txReceipt =
        await this.providers[Number(data.chainId)].getTransactionReceipt(
          txHash,
        );
      // デプロイはやり直せない。アドレスと tx は必ず追跡できるようにする。
      this.logger.debug(
        `contract deployed: address=${txReceipt?.contractAddress} tx=${txHash} chain=${data.chainId}`,
        'ContractDeployment',
      );
      return txReceipt;
    } catch (e) {
      this.logger.error(
        `Failed to deploy contract (contractId=${data.contractId} chain=${data.chainId})`,
        e,
        'ContractDeployment',
      );
      return e;
    }
  }

  async getContractName(
    contractAddress: string,
    chainId: string,
  ): Promise<string | Error> {
    if (!this.providers[Number(chainId)]) {
      this.logger.warn(
        `unsupported chain: ${chainId} (getContractName ${contractAddress})`,
        Web3Service.name,
      );
      return new Error('Unsupported blockchains');
    }
    const contract = new ethers.Contract(
      contractAddress,
      [
        {
          name: 'name',
          type: 'function',
          inputs: [],
          outputs: [{ name: '', type: 'string', internalType: 'string' }],
          stateMutability: 'view',
        },
      ],
      this.providers[Number(chainId)],
    );
    return contract.name();
  }

  private getSecretKey = async (secretname: string) => {
    try {
      const secretName = secretname;
      const client = new SecretsManager({
        region: 'ap-northeast-1',
      });
      const response = await client.send(
        new GetSecretValueCommand({
          SecretId: secretName,
          VersionStage: 'AWSCURRENT',
        }),
      );
      const secretKey = await String(response.SecretString);
      return secretKey;
    } catch (error) {
      this.logger.error('Failed to get secret key', error, 'AWS');
      return error;
    }
  };

  private _execute =
    (method: Method) =>
    (...inputs: any) =>
    async (callCount: number = 0) => {
      const contract = new ethers.Contract(
        method.contractAddress,
        method.abi,
        method.wallet,
      );
      this.logger.debug(
        `Start to execute ${method.method} (${callCount})`,
        Web3Service.name,
      );
      let response: ethers.ContractTransactionResponse;
      let hash: string;

      try {
        response = await contract[method.method](...inputs);
        hash = response.hash;
      } catch (error) {
        this.logger.error(
          `Faild to execute ${method.method}`,
          error,
          Web3Service.name,
        );
        if (callCount >= method.callLimit ? method.callLimit : 0) {
          throw error;
        }
        if (
          ethers.isError(error, 'NETWORK_ERROR') ||
          ethers.isError(error, 'TIMEOUT') ||
          ethers.isError(error, 'SERVER_ERROR') ||
          ethers.isError(error, 'UNKNOWN_ERROR')
        ) {
          const delay = 2 ** callCount * BASE_DELAY;
          // 再試行は「遅い」の原因になる。何回目で何 ms 待ったかを残す。
          this.logger.warn(
            `retrying ${method.method} in ${delay}ms (attempt ${callCount + 1}/${method.callLimit})`,
            Web3Service.name,
          );
          await this._sleep(delay);

          // **戻り値を返すこと。** return が無いと再試行の結果が捨てられ、
          // そのまま下の `response.wait` へ落ちて response が undefined の
          // まま TypeError になる (リトライしたのに失敗するのはこれが原因)。
          return await this._execute(method)(...inputs)(callCount + 1);
        } else {
          throw error;
        }
      }
      try {
        if (typeof response.wait === 'function') {
          this.logger.debug(
            `Waiting for the transaction to be mined.`,
            Web3Service.name,
          );
          let receipt: ethers.TransactionReceipt | null;
          receipt = await response.wait();
          if (receipt) {
            return receipt;
          } else {
            let count = 0;
            while (receipt || count < method.callLimit) {
              this.logger.debug(
                `Retry waiting for the transaction to be mined. (${count})`,
                Web3Service.name,
              );
              const delay = 2 ** count * BASE_DELAY;
              await this._sleep(delay);
              await response.wait();
              receipt = await this.wallet.provider.getTransactionReceipt(hash);
              count++;
            }
            if (receipt) return receipt;
            throw new Error('TIMEOUT');
          }
        } else {
          return response;
        }
      } catch (error) {
        this.logger.error(
          'Failed to wait for the transaction to be mined',
          error,
          Web3Service.name,
        );
        throw error;
      }
    };

  private _sleep = (ms: number) =>
    new Promise((resolve) => setTimeout(resolve, ms));
}

class AutoGasSuggestProvider extends ethers.JsonRpcProvider {
  async getFeeData(): Promise<ethers.FeeData> {
    const rewardPercentile: number = 75;

    const history = (await this.send('eth_feeHistory', [
      '0x1',
      'latest',
      [rewardPercentile],
    ])) as {
      baseFeePerGas: string[];
      reward: string[][];
    };

    const feeData = {
      maxPriorityFeePerGas: BigInt(history.reward[0][0]),
      maxFeePerGas:
        BigInt(history.baseFeePerGas[1]) + BigInt(history.reward[0][0]),
    } as ethers.FeeData;
    return feeData;
  }
}
