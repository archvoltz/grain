import { Inject, Injectable } from '@nestjs/common';
import { PrismaService } from 'src/prisma.service';
import { ProjectContract, Prisma } from '../generated/prisma/client';
import { APP_LOGGER } from '../logger/app-logger';
import type { AppLogger } from '../logger/app-logger';

@Injectable()
export class ProjectContractService {
  constructor(
    private prisma: PrismaService,
    @Inject(APP_LOGGER) private readonly logger: AppLogger,
  ) {}

  async createProjectContract(
    data: Prisma.ProjectContractCreateInput,
  ): Promise<ProjectContract> {
    try {
      const result = await this.prisma.projectContract.create({
        data,
      });

      this.logger.log(
        `contract linked: project=${result?.projectId} address=${result?.address}`,
        'ProjectContractService',
      );
      return result;
    } catch (error) {
      const err = error instanceof Error ? error : new Error(String(error));
      this.logger.error(
        `createProjectContract failed: ${err.message}`,
        err,
        'ProjectContractService',
      );
      throw error;
    }
  }

  async getProjectContracts(params: {
    skip?: number;
    take?: number;
    cursor?: Prisma.ProjectContractWhereUniqueInput;
    where?: Prisma.ProjectContractWhereUniqueInput;
    orderBy?: Prisma.ProjectContractOrderByWithRelationInput;
  }): Promise<ProjectContract[]> {
    const { skip, take, cursor, where, orderBy } = params;
    try {
      const result = await this.prisma.projectContract.findMany({
        skip,
        take,
        cursor,
        where,
        orderBy,
      });
      this.logger.debug(
        `projectContracts fetched: ${result.length}`,
        'ProjectContractService',
      );
      return result;
    } catch (error) {
      const err = error instanceof Error ? error : new Error(String(error));
      this.logger.error(
        `getProjectContracts failed: ${err.message}`,
        err,
        'ProjectContractService',
      );
      throw error;
    }
  }

  async updateProjectContracts(params: {
    where: Prisma.ProjectContractWhereUniqueInput;
    data: Prisma.ProjectContractUpdateInput;
  }): Promise<ProjectContract> {
    const { where, data } = params;
    try {
      const result = await this.prisma.projectContract.update({
        where,
        data,
      });
      this.logger.debug(
        `projectContract updated: project=${result?.projectId} address=${result?.address}`,
        'ProjectContractService',
      );
      return result;
    } catch (error) {
      const err = error instanceof Error ? error : new Error(String(error));
      this.logger.error(
        `updateProjectContracts failed: ${err.message}`,
        err,
        'ProjectContractService',
      );
      throw error;
    }
  }

  async deleteProjectContracts(
    where: Prisma.ProjectContractWhereUniqueInput,
  ): Promise<ProjectContract> {
    try {
      const result = await this.prisma.projectContract.delete({
        where,
      });

      // 紐付けを外すと API から叩けなくなる。戻せないので INFO。
      this.logger.log(
        `contract unlinked: project=${result?.projectId} address=${result?.address}`,
        'ProjectContractService',
      );
      return result;
    } catch (error) {
      const err = error instanceof Error ? error : new Error(String(error));
      this.logger.error(
        `deleteProjectContracts failed: ${err.message}`,
        err,
        'ProjectContractService',
      );
      throw error;
    }
  }
}
