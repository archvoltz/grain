import { Inject, Injectable } from '@nestjs/common';
import { Prisma, Role } from '../generated/prisma/client';
import { PrismaService } from 'src/prisma.service';
import { APP_LOGGER } from '../logger/app-logger';
import type { AppLogger } from '../logger/app-logger';

@Injectable()
export class RoleService {
  constructor(
    private prisma: PrismaService,
    @Inject(APP_LOGGER) private readonly logger: AppLogger,
  ) {}

  async createRole(_newRole: Prisma.RoleCreateInput): Promise<string | Role> {
    try {
      const res = await this.prisma.role.create({ data: _newRole });
      this.logger.debug(`role created: ${res?.roleId}`, 'RoleService');
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(`createRole failed: ${err.message}`, err, 'RoleService');
      throw e;
    }
  }

  async getAllRoles(): Promise<Role[]> {
    try {
      const res = await this.prisma.role.findMany();
      this.logger.debug(`roles in total: ${res.length}`, 'RoleService');
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `getAllRoles failed: ${err.message}`,
        err,
        'RoleService',
      );
      throw e;
    }
  }

  async getRoleById(_roleId: Prisma.RoleWhereUniqueInput): Promise<Role> {
    try {
      const res = await this.prisma.role.findUnique({
        where: _roleId,
        select: {
          roleId: true,
          name: true,
          limit: true,
          description: true,
        },
      });

      // 見つからないのは **クエリとしては成功**なので拡張からは見えない。
      // 404 相当なので ERROR ではなく WARN (アクセスログの 4xx と同じ温度感)。
      if (!res) {
        this.logger.warn(
          `role not found: ${String(_roleId?.roleId)}`,
          'RoleService',
        );
      }
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(
        `getRoleById failed: ${err.message}`,
        err,
        'RoleService',
      );
      throw e;
    }
  }

  async updateRole(params: {
    where: Prisma.RoleWhereUniqueInput;
    data: Prisma.RoleUpdateInput;
  }): Promise<Role> {
    const { where, data } = params;
    try {
      const res = await this.prisma.role.update({
        where,
        data,
        select: {
          roleId: true,
          name: true,
          limit: true,
          description: true,
        },
      });
      this.logger.debug(`role updated: ${res?.roleId}`, 'RoleService');
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(`updateRole failed: ${err.message}`, err, 'RoleService');
      throw e;
    }
  }

  async deleteRole(where: Prisma.RoleWhereUniqueInput): Promise<any> {
    try {
      const res = await this.prisma.role.delete({
        where,
        select: {
          roleId: true,
          name: true,
          limit: true,
          description: true,
        },
      });

      // 削除は戻せないので debug ではなく INFO。本番で debug を切っても残す。
      this.logger.log(`role deleted: ${res?.roleId}`, 'RoleService');
      return res;
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      this.logger.error(`deleteRole failed: ${err.message}`, err, 'RoleService');
      throw e;
    }
  }
}
