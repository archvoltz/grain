import * as dotenv from 'dotenv';
dotenv.config({ quiet: true });
import * as util from 'util';
import { Injectable, Optional } from '@nestjs/common';
import { buildLogRecord, severityFromStatus } from './log-line';
import type { ErrorFields, HttpFields, LogFields } from './log-line';
import { RequestContextService } from '../requestContext.service';
import type { AppLogger } from './app-logger';

export type Severity = 'info' | 'warn' | 'error' | 'debug';

const SEVERITY_TO_COMMON: Record<Severity, LogFields['severity']> = {
  info: 'INFO',
  warn: 'WARN',
  error: 'ERROR',
  debug: 'DEBUG',
};

const DEFAULT_SEVERITIES: Severity[] = ['info', 'warn', 'error', 'debug'];

type LogFormat = 'json' | 'text';

export interface CustomLoggerOptions {
  severities?: Severity[];
  format?: LogFormat;
}

export const customLoggerOptions: CustomLoggerOptions =
  process.env.NODE_ENV === 'development'
    ? { severities: ['debug', 'info', 'warn', 'error'], format: 'text' }
    : { severities: ['info', 'warn', 'error'], format: 'json' };

type ColorTextFn = (text: string) => string;

const isColorAllowed = () => !process.env.NO_COLOR;
const colorIfAllowed = (colorFn: ColorTextFn) => (text: string) =>
  isColorAllowed() ? colorFn(text) : text;

const clc = {
  bold: colorIfAllowed((text: string) => `\x1B[1m${text}\x1B[0m`),
  green: colorIfAllowed((text: string) => `\x1B[32m${text}\x1B[39m`),
  yellow: colorIfAllowed((text: string) => `\x1B[33m${text}\x1B[39m`),
  red: colorIfAllowed((text: string) => `\x1B[31m${text}\x1B[39m`),
  magentaBright: colorIfAllowed((text: string) => `\x1B[95m${text}\x1B[39m`),
  cyanBright: colorIfAllowed((text: string) => `\x1B[96m${text}\x1B[39m`),
};

const yellow = colorIfAllowed((text: string) => `\x1B[38;5;3m${text}\x1B[39m`);

const isPlainObject = (fn: unknown): fn is object => {
  if (typeof fn !== 'object') {
    return false;
  }
  const proto = Object.getPrototypeOf(fn);
  if (proto === null) {
    return true;
  }
  const ctor =
    Object.prototype.hasOwnProperty.call(proto, 'constructor') &&
    proto.constructor;
  return (
    typeof ctor === 'function' &&
    ctor instanceof ctor &&
    Function.prototype.toString.call(ctor) ===
      Function.prototype.toString.call(Object)
  );
};

const dateTimeFormatter = new Intl.DateTimeFormat(undefined, {
  year: 'numeric',
  hour: 'numeric',
  minute: 'numeric',
  second: 'numeric',
  day: '2-digit',
  month: '2-digit',
});

@Injectable()
export class CustomLoggerService implements AppLogger {
  protected options: CustomLoggerOptions;
  /** log() の呼び出しで context 引数が無かったときに使う既定値。 */
  protected context?: string;

  constructor(
    private readonly requestContext: RequestContextService,
    @Optional() options: CustomLoggerOptions = customLoggerOptions,
  ) {
    this.options = {
      ...options,
      severities: options.severities ?? DEFAULT_SEVERITIES,
      format: options.format ?? 'text',
    };
  }

  /**
   * Write a 'log' level log, if the configured level allows for it.
   * Prints to `stdout` with newline.
   */
  log(message: unknown, ...metadata: [...any, string?]): void;
  log(message: unknown, ...metadata: any[]): void {
    if (!this.isLevelEnabled('info')) {
      return;
    }
    const { messages, context } = this.getContextAndMessagesToPrint([
      message,
      ...metadata,
    ]);
    this.printCommonLine(messages, context, '', 'info');
  }

  debug(message: unknown, ...metadata: [...any, string?]): void;
  debug(message: unknown, ...metadata: any[]): void {
    if (!this.isLevelEnabled('debug')) {
      return;
    }
    const { messages, context } = this.getContextAndMessagesToPrint([
      message,
      ...metadata,
    ]);
    this.printCommonLine(messages, context, '', 'debug');
  }

  warn(message: unknown, ...metadata: [...any, string?]): void;
  warn(message: unknown, ...metadata: any[]): void {
    if (!this.isLevelEnabled('warn')) {
      return;
    }
    const { messages, context } = this.getContextAndMessagesToPrint([
      message,
      ...metadata,
    ]);
    this.printCommonLine(messages, context, '', 'warn');
  }

  error(message: unknown, stackOrContext?: string): void;
  error(message: unknown, stack?: string, context?: string): void;
  error(message: unknown, ...metadata: any[]): void;
  error(message: unknown, ...metadata: any[]): void {
    if (!this.isLevelEnabled('error')) {
      return;
    }
    const { messages, context, stack } =
      this.getContextAndStackAndMessagesToPrint([message, ...metadata]);

    this.printCommonLine(messages, context, stack, 'error');
  }

  setContext(context: string) {
    this.context = context;
  }

  /** setContext で付けた既定 context を外す。 */
  resetContext() {
    this.context = undefined;
  }

  isLevelEnabled(level: Severity): boolean {
    const logLevels = this.options?.severities;
    return logLevels.includes(level);
  }

  protected printMessages(
    messages: unknown[],
    context = '',
    severity: Severity = 'info',
    writeStreamType?: 'stdout' | 'stderr',
  ) {
    messages.forEach((message) => {
      const pidMessage = this.formatPid(process.pid);
      const contextMessage = this.formatContext(context);
      const formattedSeverity = severity.toUpperCase().padStart(7, ' ');
      const formattedMessage = this.formatMessage(
        severity,
        message,
        pidMessage,
        formattedSeverity,
        contextMessage,
      );
      this.write(formattedMessage, writeStreamType ?? 'stdout');
    });
  }

  /**
   * ログ 1 件。**共通ログ行と同じキー・順序**の record を作る
   * (logger/log-line.ts の LogFields)。format による違いは
   * writeLogLine の中の「見た目」だけで、record の中身は同じ。
   *
   * 以前は text モードだけ message しか出さない別系統だったので、開発中は
   * requestId / userId / clientIp が見えなかった。アクセスログと同じ形に
   * そろえることで「そのログがどのリクエストのものか」が開発でも分かる。
   */
  protected printCommonLine(
    messages: unknown[],
    context = '',
    stack = '',
    severity: Severity = 'info',
  ) {
    const request = this.requestContext.get();
    messages.forEach((message) => {
      const text =
        typeof message === 'string' ? message : JSON.stringify(message);
      this.writeLogLine(
        {
          clientIp: request?.clientIp,
          severity: SEVERITY_TO_COMMON[severity],
          requestId: request?.requestId,
          userId: request?.userId,
          // 「どこが出したか」を落とさないよう [RouterExplorer] 形式で前置する
          message: context ? `[${context}] ${text}` : text,
          UserAgent: request?.UserAgent,
        },
        {},
        // stack があるものだけ error を付ける。無ければキー自体が出ない。
        stack ? { code: '', type: '', detail: '', stack } : undefined,
        // text モードでは JSON 文字列ではなく元のオブジェクトを展開したいので、
        // 文字列でないときだけ生の値を渡す。
        typeof message === 'string' ? undefined : message,
      );
    });
  }

  /**
   * HTTP アクセスログ 1 行 (`event: 'http_request'`)。
   * HttpLoggerMiddleware が res の finish 時に 1 回だけ呼ぶ。
   */
  httpAccess(
    http: HttpFields,
    options: { message?: string; error?: Partial<ErrorFields> } = {},
  ): void {
    const request = this.requestContext.get();
    this.writeLogLine(
      {
        clientIp: request?.clientIp,
        severity: severityFromStatus(http.status),
        event: 'http_request',
        requestId: request?.requestId,
        userId: request?.userId,
        // エラー時は利用者に見せた文言。正常時は空。
        message: options.message,
        UserAgent: request?.UserAgent,
      },
      http,
      options.error,
    );
  }

  protected printStackTrace(stack: string) {
    if (!stack) {
      return;
    }
    this.write(`${stack}\n`, 'stderr');
  }

  /**
   * このクラスから出る書き出しは全部ここを通す。
   * （標準入出力の直書きはフォーマットの統一しづらいのでやめた）
   *
   * **ここでは整形しない。** 以前は「JSON の形をした文字列なら parse して
   * util.inspect で展開」していたが、format を見ていないため本番 (json) でも
   * 共通ログ行が色付き複数行に化け、Fluent Bit の parser が落とす形になって
   * いた。整形は format を知っている writeLogLine 側でやる。
   */
  private write(text: string, stream: 'stdout' | 'stderr' = 'stdout'): void {
    process[stream].write(text);
  }
  // write(text: string, stream: 'stdout' | 'stderr' = 'stdout'): void {
  //   if (this.options.format == 'text') {
  //     if (typeof text === 'string') {
  //       const trimmed = text.trim();
  //       if (
  //         (trimmed.startsWith('{') && trimmed.endsWith('}')) ||
  //         (trimmed.startsWith('[') && trimmed.endsWith(']'))
  //       ) {
  //         try {
  //           const parsed = JSON.parse(trimmed);

  //           // パースに成功したら、整形して書き出し（インデント2スペースの場合。1行にしたいなら引数は parsed のみ）
  //           const jsonString = JSON.stringify(parsed, null, 2) + '\n';
  //           process[stream].write(jsonString);
  //           return;
  //         } catch (e) {
  //           // パース失敗時は何もしない（下の通常の書き出しへ流す）
  //         }
  //       }
  //     }
  //   }

  //   // JSONではない、またはパースに失敗した場合はそのまま出力
  //   process[stream].write(text);
  // }

  /**
   * 共通ログ行 1 件を書き出す。**record は 1 か所で作り、format で見た目だけ
   * 変える**（キーと順序の定義は log-line.ts の buildLogRecord が唯一）。
   *
   * json … 1 行 JSON。Fluent Bit が「JSON デコードのみ」で拾える形。
   *        装飾を混ぜないこと (混ざると parser がマッチせず落ちる)。
   * text … Nest 標準の接頭辞 (pid / 時刻 / severity) を付け、record を
   *        util.inspect で展開して色付きで出す。stack は escape すると
   *        読めないので record から外し、生のまま stderr へ流す。
   *
   * アクセスログ (httpAccess) もここを通るので、開発時は同じ見た目になる。
   */
  private writeLogLine(
    partial: Partial<LogFields> = {},
    extra: Partial<HttpFields> = {},
    error?: Partial<ErrorFields>,
    rawMessage?: unknown,
  ): void {
    const record = buildLogRecord(partial, extra, error);

    if (this.options.format === 'json') {
      this.write(JSON.stringify(record) + '\n');
      return;
    }

    // 文字列でない message は JSON 文字列のままだと読めないので元の値に戻す
    if (rawMessage !== undefined) record.message = rawMessage;

    const errorField = record.error as { stack?: string } | undefined;
    const rawStack = errorField?.stack;
    if (errorField) delete errorField.stack;

    const severity = String(record.severity ?? 'INFO').toLowerCase() as Severity;
    const color = this.getColorBySeverity(severity);
    const level = color(severity.toUpperCase().padStart(7, ' '));
    this.write(
      `${color(this.formatPid(process.pid))}${this.getTimestamp()} ${level} ` +
        util.inspect(record, { colors: true, depth: null }) +
        '\n',
    );
    if (rawStack) this.printStackTrace(rawStack);
  }

  protected formatPid(pid: number): string {
    return `[Nest] ${pid}  - `;
  }

  protected formatContext(context: string): string {
    return context ? yellow(`[${context}]`) : '';
  }

  protected formatMessage(
    severity: Severity,
    message: unknown,
    pidMessage: string,
    formattedSeverity: string,
    contextMessage: string,
  ) {
    const output = this.stringifyMessage(message, severity);
    pidMessage = this.colorize(pidMessage, severity);
    formattedSeverity = this.colorize(formattedSeverity, severity);

    return `${pidMessage}${this.getTimestamp()} ${formattedSeverity} ${contextMessage}${output}\n`;
  }

  protected getColorBySeverity(severity: Severity) {
    switch (severity) {
      case 'debug':
        return clc.magentaBright;
      case 'warn':
        return clc.yellow;
      case 'error':
        return clc.red;
      default:
        return clc.green;
    }
  }

  protected colorize(message: string, severity: Severity) {
    const color = this.getColorBySeverity(severity);
    return color(message);
  }

  /**
   * メッセージの処理
   */

  protected stringifyMessage(message: unknown, severity: Severity) {
    if (typeof message === 'function') {
      const messageAsStr = Function.prototype.toString.call(message); //nestJS本家の実装に合わせる

      const isClass = messageAsStr.startsWith('class ');
      if (isClass) {
        return this.stringifyMessage(message.name, severity);
      }

      return this.stringifyMessage(message(), severity);
    }

    return isPlainObject(message) || Array.isArray(message)
      ? `${this.colorize('Object:', severity)}\n${JSON.stringify(message, (key, value) => (typeof value === 'bigint' ? value.toString() : value), 2)}\n` //()を追加
      : this.colorize(message as string, severity);
  }

  private getContextAndMessagesToPrint(args: unknown[]) {
    if (args.length <= 1) {
      return { messages: args, context: this.context };
    }

    const lastElement = args[args.length - 1];
    const isContext = typeof lastElement === 'string';
    if (!isContext) {
      return { message: args, context: this.context };
    }

    return {
      context: lastElement as string,
      messages: args.slice(0, args.length - 1),
    };
  }

  private getContextAndStackAndMessagesToPrint(args: unknown[]) {
    if (args.length === 2) {
      if (args[1] instanceof Error) {
        return {
          messages: [args[0]],
          stack: args[1].stack,
          context: this.context,
        };
      }
      return this.isStackFormat(args[1])
        ? {
            messages: [args[0]], //0が正しい？
            stack: args[1] as string,
            context: this.context,
          }
        : {
            messages: [args[0]],
            context: args[1] as string,
          };
    }
    const { messages, context } = this.getContextAndMessagesToPrint(args);

    if (messages?.length < 1) {
      return { messages, context };
    }

    const lastElement = messages[messages.length - 1];

    if (lastElement instanceof Error) {
      return {
        messages: messages.slice(0, messages.length - 1),
        stack: lastElement.stack,
        context: context,
      };
    }

    const isStack = this.isStackFormat(lastElement);
    if (!isStack) {
      return { messages, context };
    }
    return {
      stack: lastElement as string,
      messages: messages.slice(0, messages.length - 1),
      context,
    };
  }

  private isStackFormat(stack: unknown) {
    if (typeof stack !== 'string' && typeof stack !== 'undefined') {
      return false;
    }

    return /^(.)+\n\s+at .+:\d+:\d+$/.test(stack);
  }

  protected getTimestamp(): string {
    return dateTimeFormatter.format(Date.now());
  }
}
